(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-modules-services-services-module"],{

/***/ "./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.css":
/*!**********************************************************************************************************************************!*\
  !*** ./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.css ***!
  \**********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".section-title {\r\n  max-width: none;\r\n  margin: 0 auto;\r\n  margin-bottom: 50px;\r\n}\r\n.w3l-faq-1 .faq-top {\r\n  max-width: none;\r\n  margin: 0 auto;\r\n}\r\n.w3l-faq-1 .faq-content {\r\n  padding: 0px 0;\r\n}\r\n.w3l-content-with-photo-23 #cwp23-block {\r\n  padding: 5rem 0 3rem 0;\r\n}\r\nul {\r\n  margin-left: 20px;\r\n}\r\nli {\r\n  list-style-type: circle;\r\n  font-size: 16px;\r\n  line-height: 24px;\r\n  color: var(--text-color);\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9zZXJ2aWNlcy9wYWdlcy9kZXZlbG9wbWVudC1hbmQtdGVjaG5pY2FsLWludGVncmF0aW9uL2RldmVsb3BtZW50LWFuZC10ZWNobmljYWwtaW50ZWdyYXRpb24uY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQWU7RUFDZixjQUFjO0VBQ2QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxlQUFlO0VBQ2YsY0FBYztBQUNoQjtBQUNBO0VBQ0UsY0FBYztBQUNoQjtBQUNBO0VBQ0Usc0JBQXNCO0FBQ3hCO0FBQ0E7RUFDRSxpQkFBaUI7QUFDbkI7QUFDQTtFQUNFLHVCQUF1QjtFQUN2QixlQUFlO0VBQ2YsaUJBQWlCO0VBQ2pCLHdCQUF3QjtBQUMxQiIsImZpbGUiOiJzcmMvYXBwL21vZHVsZXMvc2VydmljZXMvcGFnZXMvZGV2ZWxvcG1lbnQtYW5kLXRlY2huaWNhbC1pbnRlZ3JhdGlvbi9kZXZlbG9wbWVudC1hbmQtdGVjaG5pY2FsLWludGVncmF0aW9uLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2VjdGlvbi10aXRsZSB7XHJcbiAgbWF4LXdpZHRoOiBub25lO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbn1cclxuLnczbC1mYXEtMSAuZmFxLXRvcCB7XHJcbiAgbWF4LXdpZHRoOiBub25lO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcbi53M2wtZmFxLTEgLmZhcS1jb250ZW50IHtcclxuICBwYWRkaW5nOiAwcHggMDtcclxufVxyXG4udzNsLWNvbnRlbnQtd2l0aC1waG90by0yMyAjY3dwMjMtYmxvY2sge1xyXG4gIHBhZGRpbmc6IDVyZW0gMCAzcmVtIDA7XHJcbn1cclxudWwge1xyXG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG59XHJcbmxpIHtcclxuICBsaXN0LXN0eWxlLXR5cGU6IGNpcmNsZTtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IpO1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.html":
/*!***********************************************************************************************************************************!*\
  !*** ./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.html ***!
  \***********************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3>Services</h3>\n        <li><a routerLink=\"/home\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">Development &Technical Integration\n        </li>\n      </ul>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-content-with-photo-23\">\n  <div id=\"cwp23-block\">\n    <div class=\"wrapper\">\n      <div class=\"section-title align-center text-center\">\n        <h3>Development &Technical Integration\n        </h3>\n        <h4> Smart and effective solutions for businesses.</h4>\n        <p class=\"sub-paragraph\">The standard functionalities and SAP consulting solutions fulfill wide range of supply\n          chain execution business requirements and our motto is always SAP Standard first. However some times that\n          business and/or technical requirements challenge SAP standard capabilities and bespoke developments/\n          enhancements are the only fallback option. This is where you will be benefitted immensely by our Technical\n          resource capabilities.</p>\n        <p class=\"sub-paragraph\">We have experts in OOPS programming using classes/methods and specialized in Post\n          Processing Framework PPF and Business Add In BADI developments.</p>\n        <p class=\"sub-paragraph\">Most importantly they are good in identifying and leveraging on SAP standard\n          services/methods/function modules/BAPI’s As n1re customers you will see that our professional development\n          team delivers innovative results to very high quality in record time.</p>\n      </div>\n    </div>\n  </div>\n</section>\n\n<section class=\"w3l-faq-1\">\n  <div class=\"faq-content\">\n    <div class=\"wrapper\">\n\n      <div class=\"faq-top\">\n        <div class=\"faq-left\">\n\n          <!--  <h4>Frequently Asked Questions</h4>-->\n          <div class=\"faq-question\">\n            <input id=\"q1\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q1\" class=\"panel-title\"> Intuitive and Easy to Use Interfaces </label>\n            <div class=\"panel-content\">\n              <p>\n                Radio Frequency RF screens design and personalization is vital to any EWM implementations. Creating the\n                exciting and optimal user experience to execute real warehouse world processes like put\n                away/picking/internal moves is critical to long term project success.\n\n              </p>\n              <p>\n                Our professional approach towards RF development is to have a simple and easier user interaction without\n                compromising on the execution speed and the integration with back end processes and documents\n              </p>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q2\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q2\" class=\"panel-title\"> Big & Clear Picture in Mind </label>\n            <div class=\"panel-content\">\n              <p>\n                Our technical resources have good functional understanding of EWM having worked on earlier assignments\n                and they are well aware of the impact of the development to the underlying process.\n\n                <br><br>\n\n                Our functional and technical resources work closely keeping the big picture and foundational blocks in\n                mind which eliminates any surprises or major course correction later.\n\n              </p>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q3\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q3\" class=\"panel-title\"> Integration and Interfaces </label>\n            <div class=\"panel-content\">\n              <p>\n                Our development team gained skills in the areas of net weaver, XI/PI, ALE/IDOC, RFC, and WCU/MFS by\n                implementing end to end process scenarios in the following areas\n              </p>\n              <ul>\n                <li>SAP EWM interface to SAP ERP or non SAP ERP</li>\n                <li>Integration of SAP EWM to LSP systems</li>\n                <li>Integration scenarios through SAP PI /XI message broker system</li>\n                <li>Integration with SAP ERP transportation (LE-TRA) using IDOCS</li>\n                <li>Integration to ASRS, Packing systems and conveyors using Warehouse Control Units (WCU) and Material\n                  Flow Systems (MFS)</li>\n                <li>Integration to Auto ID Infrastructure through RFC enabled FM</li>\n              </ul>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q4\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q4\" class=\"panel-title\"> n1re Boosters </label>\n            <div class=\"panel-content\">\n              <p>\n                Our technical resources are working on developing End to End consulting solutions called “n1re\n                Boosters” wherein we have identified 4 to 5 Key functionalities that brings in potential synergy to EWM\n              </p>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n<br><br>"

/***/ }),

/***/ "./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.ts":
/*!*********************************************************************************************************************************!*\
  !*** ./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.ts ***!
  \*********************************************************************************************************************************/
/*! exports provided: DevelopmentAndTechnicalIntegrationComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DevelopmentAndTechnicalIntegrationComponent", function() { return DevelopmentAndTechnicalIntegrationComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var DevelopmentAndTechnicalIntegrationComponent = /** @class */ (function () {
    function DevelopmentAndTechnicalIntegrationComponent() {
    }
    DevelopmentAndTechnicalIntegrationComponent.prototype.ngOnInit = function () {
    };
    DevelopmentAndTechnicalIntegrationComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-development-and-technical-integration',
            template: __webpack_require__(/*! ./development-and-technical-integration.component.html */ "./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.html"),
            styles: [__webpack_require__(/*! ./development-and-technical-integration.component.css */ "./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], DevelopmentAndTechnicalIntegrationComponent);
    return DevelopmentAndTechnicalIntegrationComponent;
}());



/***/ }),

/***/ "./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.css":
/*!****************************************************************************************************************!*\
  !*** ./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.css ***!
  \****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".section-title {\r\n    max-width: none;\r\n    margin: 0 auto;\r\n    margin-bottom: 50px;\r\n}\r\n.w3l-faq-1 .faq-top {\r\n    max-width: none;\r\n    margin: 0 auto;\r\n}\r\n.w3l-faq-1 .faq-content {\r\n    padding: 0px 0;\r\n}\r\n.w3l-content-with-photo-23 #cwp23-block {\r\n    padding: 5rem 0 3rem 0;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9zZXJ2aWNlcy9wYWdlcy9pbXBsZW1lbnR0aW9uLWFuZC1jb25zdWx0aW5nL2ltcGxlbWVudHRpb24tYW5kLWNvbnN1bHRpbmcuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLGVBQWU7SUFDZixjQUFjO0lBQ2QsbUJBQW1CO0FBQ3ZCO0FBQ0E7SUFDSSxlQUFlO0lBQ2YsY0FBYztBQUNsQjtBQUNBO0lBQ0ksY0FBYztBQUNsQjtBQUNBO0lBQ0ksc0JBQXNCO0FBQzFCIiwiZmlsZSI6InNyYy9hcHAvbW9kdWxlcy9zZXJ2aWNlcy9wYWdlcy9pbXBsZW1lbnR0aW9uLWFuZC1jb25zdWx0aW5nL2ltcGxlbWVudHRpb24tYW5kLWNvbnN1bHRpbmcuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZWN0aW9uLXRpdGxlIHtcclxuICAgIG1heC13aWR0aDogbm9uZTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogNTBweDtcclxufVxyXG4udzNsLWZhcS0xIC5mYXEtdG9wIHtcclxuICAgIG1heC13aWR0aDogbm9uZTtcclxuICAgIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcbi53M2wtZmFxLTEgLmZhcS1jb250ZW50IHtcclxuICAgIHBhZGRpbmc6IDBweCAwO1xyXG59XHJcbi53M2wtY29udGVudC13aXRoLXBob3RvLTIzICNjd3AyMy1ibG9jayB7XHJcbiAgICBwYWRkaW5nOiA1cmVtIDAgM3JlbSAwO1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.html":
/*!*****************************************************************************************************************!*\
  !*** ./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.html ***!
  \*****************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3>Services</h3>\n        <li><a routerLink=\"/home\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">Implementation & consulting services</li>\n      </ul>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-content-with-photo-23\">\n  <div id=\"cwp23-block\">\n    <div class=\"wrapper\">\n      <div class=\"section-title align-center text-center\">\n        <h3>Implementation & consulting services</h3>\n        <h4> Smart and effective solutions for businesses.</h4>\n        <p class=\"sub-paragraph\">We have three different forms of Implementation & consulting services Apart from the\n          regular implementations we do strategic consulting for clients who are keen in changing their business\n          strategies to achieve long term goals or looking for business transformation. Also we do Niche consulting\n          specifically for impacted projects or complex integrated scenarios or in special areas like MFS /RFID\n          integration.</p>\n      </div>\n    </div>\n  </div>\n</section>\n\n<section class=\"w3l-faq-1\">\n  <div class=\"faq-content\">\n    <div class=\"wrapper\">\n\n      <div class=\"faq-top\">\n        <div class=\"faq-left\">\n\n          <!--  <h4>Frequently Asked Questions</h4>-->\n          <div class=\"faq-question\">\n            <input id=\"q1\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q1\" class=\"panel-title\">Resource Quality and Deployment </label>\n            <div class=\"panel-content\">\n              <p>We deliver projects in the most innovative and efficient way utilizing smart, passionate and dedicated\n                resources with industry and implementation expertise and also ensuring a healthy mix of resources being\n                deployed.\n              </p>\n              <p>We never compromise on resource quality and fitment to the project and as well on stringent quality\n                reviews on project deliverables</p>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q2\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q2\" class=\"panel-title\">Stay the Course & Never Throw the Towel</label>\n            <div class=\"panel-content\">\n              <p>From project kick off till go live we stay the course until you are comfortable and confident.\n                <br><br>\n                During the course of implementation our program/project management follows our values of maintaining\n                integrity, being responsible, trust worthy and quality conscious.\n              </p>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q3\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q3\" class=\"panel-title\">Listen and Collaborate</label>\n            <div class=\"panel-content\">\n              <p>We listen to customer’s requirements with open mind and we harness customer’s key competencies, expertise resulting in Flexible, Agile, Robust and Efficient (FARE) processes that will sustain and shall be enhanced flexibly.\n                <br><br>\n                We try to leverage on super user skills by training them in the EWM concepts, functionality, configuration/ development nuances the outcome of which is properly tested system covering all the applicable scenarios and trainers who can train the end users (train the trainer)\n              </p>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q4\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q4\" class=\"panel-title\">Document / Examine / Prototyping</label>\n            <div class=\"panel-content\">\n              <p> We document the process meticulously with integrated flow diagrams (Visio /ARIS) through which we close any loop holes or ambiguity in process. We know the importance of this activity which essentially helps in process robustness/comprehensiveness , sometimes it so happens that the proposed solution we have in mind will not be appropriate and needs to be revisited or tweaked a bit or to be changed entirely.\n                <br><br>\n                We do prototyping of the core processes to the extent possible so that we can confirm to the client or freeze on solution for a scenario or an end to end process.</p>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q5\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q5\" class=\"panel-title\">Digital Assets</label>\n            <div class=\"panel-content\">\n              <p>We leverage on our digital assets like best process flow diagrams and process variants, Pros and Cons Analyzer, Key Data Structure(KDS) templates for org elements standardization, Test plans, to speed up the implementation.\n                <br><br>\n                We have an extensive array of test scripts, User training manuals, Reference materials, detailed presentations customized for each engagement. We ensure that the Key lessons learnt and documented in our earlier implementations are implemented.\n                <br><br>\n                Our methods and models reduce risks and maximize the value of SAP investment and success rate</p>\n            </div>\n          </div>\n\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n<br><br>"

/***/ }),

/***/ "./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.ts":
/*!***************************************************************************************************************!*\
  !*** ./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.ts ***!
  \***************************************************************************************************************/
/*! exports provided: ImplementtionAndConsultingComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImplementtionAndConsultingComponent", function() { return ImplementtionAndConsultingComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ImplementtionAndConsultingComponent = /** @class */ (function () {
    function ImplementtionAndConsultingComponent() {
    }
    ImplementtionAndConsultingComponent.prototype.ngOnInit = function () {
    };
    ImplementtionAndConsultingComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-implementtion-and-consulting',
            template: __webpack_require__(/*! ./implementtion-and-consulting.component.html */ "./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.html"),
            styles: [__webpack_require__(/*! ./implementtion-and-consulting.component.css */ "./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ImplementtionAndConsultingComponent);
    return ImplementtionAndConsultingComponent;
}());



/***/ }),

/***/ "./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.css":
/*!********************************************************************************************!*\
  !*** ./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.css ***!
  \********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL21vZHVsZXMvc2VydmljZXMvcGFnZXMvc3RhZmZpbmctc29sdXRpb25zL3N0YWZmaW5nLXNvbHV0aW9ucy5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.html":
/*!*********************************************************************************************!*\
  !*** ./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.html ***!
  \*********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3>Services</h3>\n        <li><a routerLink=\"/home\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">Staffing Solutions\n        </li>\n      </ul>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-ecommerce-single\">\n  <!--content-->\n  <div class=\"product section-gap\">\n    <div class=\"wrapper\">\n      <div class=\"d-grid ecommerce-align\">\n        <div class=\"d-grid align-items\">\n          <div class=\"single-right-left\">\n            <div class=\"galleryContainer\">\n              <div class=\"gallery\">\n                <input type=\"radio\" name=\"controls\" id=\"c1\" checked=\"\"><img class=\"galleryImage\" id=\"i1\"\n                  src=\"assets/images/stafSolution/e7.jpg\" alt=\"\">\n              </div>\n            </div>\n          </div>\n          <div class=\"single-right-left simpleCart_shelfItem\">\n            <h3>Staffing Solutions\n            </h3>\n            <div class=\"desc_single\">\n              <p>n1re is India's leading staffing services organization, providing HR services throughout India\n                meticulously. We have remained focused to help clients focus on their own strengths. Yes, we have helped\n                them raise their productivity, by backing them with services that promise improved quality, efficiency,\n                reliability and cost-reduction across their talent assets. Our mandate is always very clear – deliver\n                specialty workforce solutions that complement our offerings. We continue to succeed in helping our\n                clients win across the table, across skills and across talent.As an efficient in the employment services\n                industry we offer a range of services for the entire employment and business cycle. Permanent,\n                temporary, flexi, contract staffing and recruitment services are supported at the back end by employee\n                assessment and training. We also offer outplacements, outsourcing and consulting services. n1re has\n                abilities to quickly attract the right talent that matches very stringent needs, and is parked with the\n                full dimension of the recruiting process. We have team of experience professional which act as catalyst.\n                We successfully address the needs of many clients – small, medium and large, including trans-nationals\n                and multinational corporations.</p>\n            </div>\n          </div>\n        </div>\n        <div class=\"clear\"> </div>\n      </div>\n    </div>\n  </div>\n</section>"

/***/ }),

/***/ "./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.ts":
/*!*******************************************************************************************!*\
  !*** ./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.ts ***!
  \*******************************************************************************************/
/*! exports provided: StaffingSolutionsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StaffingSolutionsComponent", function() { return StaffingSolutionsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var StaffingSolutionsComponent = /** @class */ (function () {
    function StaffingSolutionsComponent() {
    }
    StaffingSolutionsComponent.prototype.ngOnInit = function () {
    };
    StaffingSolutionsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-staffing-solutions',
            template: __webpack_require__(/*! ./staffing-solutions.component.html */ "./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.html"),
            styles: [__webpack_require__(/*! ./staffing-solutions.component.css */ "./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], StaffingSolutionsComponent);
    return StaffingSolutionsComponent;
}());



/***/ }),

/***/ "./src/app/modules/services/pages/support/support.component.css":
/*!**********************************************************************!*\
  !*** ./src/app/modules/services/pages/support/support.component.css ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".section-title {\r\n  max-width: none;\r\n  margin: 0 auto;\r\n  margin-bottom: 50px;\r\n}\r\n.w3l-faq-1 .faq-top {\r\n  max-width: none;\r\n  margin: 0 auto;\r\n}\r\n.w3l-faq-1 .faq-content {\r\n  padding: 0px 0;\r\n}\r\n.w3l-content-with-photo-23 #cwp23-block {\r\n  padding: 5rem 0 3rem 0;\r\n}\r\nul {\r\n  margin-left: 20px;\r\n}\r\nli {\r\n  list-style-type: circle;\r\n  font-size: 16px;\r\n  line-height: 24px;\r\n  color: var(--text-color);\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9zZXJ2aWNlcy9wYWdlcy9zdXBwb3J0L3N1cHBvcnQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLGVBQWU7RUFDZixjQUFjO0VBQ2QsbUJBQW1CO0FBQ3JCO0FBQ0E7RUFDRSxlQUFlO0VBQ2YsY0FBYztBQUNoQjtBQUNBO0VBQ0UsY0FBYztBQUNoQjtBQUNBO0VBQ0Usc0JBQXNCO0FBQ3hCO0FBQ0E7RUFDRSxpQkFBaUI7QUFDbkI7QUFDQTtFQUNFLHVCQUF1QjtFQUN2QixlQUFlO0VBQ2YsaUJBQWlCO0VBQ2pCLHdCQUF3QjtBQUMxQiIsImZpbGUiOiJzcmMvYXBwL21vZHVsZXMvc2VydmljZXMvcGFnZXMvc3VwcG9ydC9zdXBwb3J0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2VjdGlvbi10aXRsZSB7XHJcbiAgbWF4LXdpZHRoOiBub25lO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG4gIG1hcmdpbi1ib3R0b206IDUwcHg7XHJcbn1cclxuLnczbC1mYXEtMSAuZmFxLXRvcCB7XHJcbiAgbWF4LXdpZHRoOiBub25lO1xyXG4gIG1hcmdpbjogMCBhdXRvO1xyXG59XHJcbi53M2wtZmFxLTEgLmZhcS1jb250ZW50IHtcclxuICBwYWRkaW5nOiAwcHggMDtcclxufVxyXG4udzNsLWNvbnRlbnQtd2l0aC1waG90by0yMyAjY3dwMjMtYmxvY2sge1xyXG4gIHBhZGRpbmc6IDVyZW0gMCAzcmVtIDA7XHJcbn1cclxudWwge1xyXG4gIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG59XHJcbmxpIHtcclxuICBsaXN0LXN0eWxlLXR5cGU6IGNpcmNsZTtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IpO1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/modules/services/pages/support/support.component.html":
/*!***********************************************************************!*\
  !*** ./src/app/modules/services/pages/support/support.component.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3>Services</h3>\n        <li><a routerLink=\"/home\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">Support\n        </li>\n      </ul>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-content-with-photo-23\">\n  <div id=\"cwp23-block\">\n    <div class=\"wrapper\">\n      <div class=\"section-title align-center text-center\">\n        <h3>Support\n        </h3>\n        <h4> Smart and effective solutions for businesses.</h4>\n        <p class=\"sub-paragraph\">Peronesi offers a comprehensive, structured and tailored support service that fulfills\n          daily needs of operations, business protection, business continuity with focus on realization of business\n          benefits at the shortest period to the clients and most importantly peace of mind.\n          <br> <br>\n          Our resources are well adapted to work flexibly in challenging environments by hitting the ground running\n          during any stage of the project (realization , testing , go live preparation, post go live hyper care support\n          and post go live transition support)..\n          <br> <br>\n          Peronesi provides resources having good analytical skills, self driven, adaptable, customer focused, organized\n          and above all having patience that are vital in understanding the root cause of the issues and resolve them in\n          a timely manner within the agreed SLA’s.\n          <br> <br>\n          We offer on demand support which are required any time in the project and broadly classified as pre go live or\n          post go live support. Also we offer Application Managed Services (AMS) which involve complete outsourcing of\n          your application maintenance.</p>\n      </div>\n    </div>\n  </div>\n</section>\n\n<section class=\"w3l-faq-1\">\n  <div class=\"faq-content\">\n    <div class=\"wrapper\">\n\n      <div class=\"faq-top\">\n        <div class=\"faq-left\">\n\n          <!--  <h4>Frequently Asked Questions</h4>-->\n          <div class=\"faq-question\">\n            <input id=\"q1\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q1\" class=\"panel-title\"> Post go live support </label>\n            <div class=\"panel-content\">\n              <p>\n                We work on highly flexible and robust support model that will suit the operational support and budgetary\n                needs of any organization.\n                <br><br>\n                We have a clearly defined escalation matrix that guarantees timely resolution of different\n                types/categories of production issues as per SLA and to the utmost satisfaction of customers\n              </p>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q2\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q2\" class=\"panel-title\"> Application Managed Services ( AMS) </label>\n            <div class=\"panel-content\">\n              <p>\n                Faster ROI is the focus of Peronesi Application Managed Services (AMS) offering.\n                <br><br>\n                Our AMS offering is to provide complete application outsourcing including application enhancements or\n                upgrades and process optimization. You can be assured that we work as part and parcel of your IT\n                organization partnering and collaborating in delivering business value while your IT can focus on Long\n                term business objectives.\n                <br><br>\n                As part of our continuous improvement we constantly work towards identifying the critical issues which\n                requires significant changes to configuration/development. These are the issues which will not be\n                addressed through quick fixes or work around measures and also if addressed bring in significant\n                business value and importantly peace of mind. Through our optimization service offering of AMS we work\n                on these critical issues closely with the client IT department for speedier and permanent resolution.\n              </p>\n            </div>\n          </div>\n          <div class=\"faq-question\">\n            <input id=\"q3\" type=\"checkbox\" class=\"panel\">\n            <div class=\"plus\">+</div>\n            <label for=\"q3\" class=\"panel-title\"> Pre go live support</label>\n            <div class=\"panel-content\">\n              <p>\n                In a life cycle of project especially during realization and testing phase there could be need for\n                additional hands or experts to meet the deadlines there could be support requirements like\n              </p>\n              <ul>\n                <li>Completing certain configuration</li>\n                <li>Complex enhancement</li>\n                <li>Rolling out the global templates with local variants</li>\n                <li>Test case / Test variants preparation and execution.</li>\n              </ul>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n<br><br>"

/***/ }),

/***/ "./src/app/modules/services/pages/support/support.component.ts":
/*!*********************************************************************!*\
  !*** ./src/app/modules/services/pages/support/support.component.ts ***!
  \*********************************************************************/
/*! exports provided: SupportComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SupportComponent", function() { return SupportComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var SupportComponent = /** @class */ (function () {
    function SupportComponent() {
    }
    SupportComponent.prototype.ngOnInit = function () {
    };
    SupportComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-support',
            template: __webpack_require__(/*! ./support.component.html */ "./src/app/modules/services/pages/support/support.component.html"),
            styles: [__webpack_require__(/*! ./support.component.css */ "./src/app/modules/services/pages/support/support.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], SupportComponent);
    return SupportComponent;
}());



/***/ }),

/***/ "./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.css":
/*!**********************************************************************************************!*\
  !*** ./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.css ***!
  \**********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".w3l-content-with-photo-23 .cwp23-content {\r\n    grid-template-columns: 1fr 1fr;\r\n    grid-column-gap: 3rem;\r\n  }\r\n  .w3l-features-6 .fea-gd-vv {\r\n    /* grid-template-columns: 1fr 1fr 1fr; */\r\n    grid-template-columns: none;\r\n    display: grid;\r\n    grid-gap: 20px;\r\n  }\r\n  li {\r\n    list-style-type: circle;\r\n    font-size: 16px;\r\n    line-height: 24px;\r\n    color: var(--text-color);\r\n  }\r\n  .w3l-features-6 .features {\r\n    padding: 0px 0;\r\n  }\r\n  .w3l-content-with-photo-23 #cwp23-block {\r\n    padding: 5rem 0 1rem;\r\n  }\r\n  .w3l-content-with-photo-3 .top-bottom {\r\n    padding: 0px 0px;\r\n}\r\n  .w3l-content-with-photo-3 .ser-sing {\r\n  margin-top: 0px;\r\n}\r\n  .w3l-content-with-photo-3 .ser-top {\r\n  min-height: 242px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9zZXJ2aWNlcy9wYWdlcy96ZXJvLWNvc3QtYmVuY2htYXJrL3plcm8tY29zdC1iZW5jaG1hcmsuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLDhCQUE4QjtJQUM5QixxQkFBcUI7RUFDdkI7RUFDQTtJQUNFLHdDQUF3QztJQUN4QywyQkFBMkI7SUFDM0IsYUFBYTtJQUNiLGNBQWM7RUFDaEI7RUFDQTtJQUNFLHVCQUF1QjtJQUN2QixlQUFlO0lBQ2YsaUJBQWlCO0lBQ2pCLHdCQUF3QjtFQUMxQjtFQUNBO0lBQ0UsY0FBYztFQUNoQjtFQUNBO0lBQ0Usb0JBQW9CO0VBQ3RCO0VBRUE7SUFDRSxnQkFBZ0I7QUFDcEI7RUFDQTtFQUNFLGVBQWU7QUFDakI7RUFDQTtFQUNFLGlCQUFpQjtBQUNuQiIsImZpbGUiOiJzcmMvYXBwL21vZHVsZXMvc2VydmljZXMvcGFnZXMvemVyby1jb3N0LWJlbmNobWFyay96ZXJvLWNvc3QtYmVuY2htYXJrLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudzNsLWNvbnRlbnQtd2l0aC1waG90by0yMyAuY3dwMjMtY29udGVudCB7XHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnI7XHJcbiAgICBncmlkLWNvbHVtbi1nYXA6IDNyZW07XHJcbiAgfVxyXG4gIC53M2wtZmVhdHVyZXMtNiAuZmVhLWdkLXZ2IHtcclxuICAgIC8qIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyIDFmciAxZnI7ICovXHJcbiAgICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IG5vbmU7XHJcbiAgICBkaXNwbGF5OiBncmlkO1xyXG4gICAgZ3JpZC1nYXA6IDIwcHg7XHJcbiAgfVxyXG4gIGxpIHtcclxuICAgIGxpc3Qtc3R5bGUtdHlwZTogY2lyY2xlO1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcik7XHJcbiAgfVxyXG4gIC53M2wtZmVhdHVyZXMtNiAuZmVhdHVyZXMge1xyXG4gICAgcGFkZGluZzogMHB4IDA7XHJcbiAgfVxyXG4gIC53M2wtY29udGVudC13aXRoLXBob3RvLTIzICNjd3AyMy1ibG9jayB7XHJcbiAgICBwYWRkaW5nOiA1cmVtIDAgMXJlbTtcclxuICB9XHJcblxyXG4gIC53M2wtY29udGVudC13aXRoLXBob3RvLTMgLnRvcC1ib3R0b20ge1xyXG4gICAgcGFkZGluZzogMHB4IDBweDtcclxufVxyXG4udzNsLWNvbnRlbnQtd2l0aC1waG90by0zIC5zZXItc2luZyB7XHJcbiAgbWFyZ2luLXRvcDogMHB4O1xyXG59XHJcbi53M2wtY29udGVudC13aXRoLXBob3RvLTMgLnNlci10b3Age1xyXG4gIG1pbi1oZWlnaHQ6IDI0MnB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.html":
/*!***********************************************************************************************!*\
  !*** ./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.html ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3>Services</h3>\n        <li><a routerLink=\"/home\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">Zero cost Bench mark Analysis</li>\n      </ul>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-content-with-photo-23\">\n  <div id=\"cwp23-block\">\n    <div class=\"wrapper\">\n      <div class=\"section-title align-center text-center\">\n        <h3>Zero cost Bench mark Analysis</h3>\n        <h4> Smart and effective solutions for businesses.</h4>\n        <p class=\"sub-paragraph\">n1re provides comprehensive solutions and services that meet and exceed the business\n          needs and goals of our clients.</p>\n      </div>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-content-with-photo-3\">\n  <div class=\"customers3 top-bottom\">\n    <div class=\"wrapper\">\n      <div class=\"ser-sing\">\n        <div class=\"ser-top sing-left\">\n          <div class=\"ser-left\">\n            <span class=\"fa fa-lightbulb-o\"></span>\n          </div>\n          <div class=\"ser-right\">\n            <h4>Creative processes</h4>\n            <p>We conduct a 2 to 3 hrs work shop through video call/conferencing followed by a customized questionnaire to understand your high level processes. </p>\n          </div>\n        </div>\n        <div class=\"ser-top sing-right\">\n          <div class=\"ser-left\">\n            <span class=\"fa fa-shield\"></span>\n          </div>\n          <div class=\"ser-right\">\n            <h4>Better Understand</h4>\n            <p>This bench marking exercise will help you to better understand the potential gaps and pain points in your business in comparison to industry best business processes. Also it helps in setting up priorities and high level road map to achieve the business objectives</p>\n          </div>\n        </div>\n        <div class=\"ser-top sing-left1\">\n          <div class=\"ser-left\">\n            <span class=\"fa fa-user-secret\"></span>\n          </div>\n          <div class=\"ser-right\">\n            <h4>Objective Analysis</h4>\n            <ul>\n              <li>Improved high level process flow To-Be diagrams  </li>\n              <li>Technical Assessment report shall be discussed  with our experts through conference call</li>\n            </ul>\n          </div>\n        </div>\n        <div class=\"ser-top sing-right1\">\n          <div class=\"ser-left\">\n            <span class=\"fa fa-handshake-o\"></span>\n          </div>\n          <div class=\"ser-right\">\n            <h4>Benefits</h4>\n            <p>High level prioritization of potential changes and expected benefits with a detailed pros and cons analysis.</p>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n<br>"

/***/ }),

/***/ "./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.ts":
/*!*********************************************************************************************!*\
  !*** ./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.ts ***!
  \*********************************************************************************************/
/*! exports provided: ZeroCostBenchmarkComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ZeroCostBenchmarkComponent", function() { return ZeroCostBenchmarkComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var ZeroCostBenchmarkComponent = /** @class */ (function () {
    function ZeroCostBenchmarkComponent() {
    }
    ZeroCostBenchmarkComponent.prototype.ngOnInit = function () {
    };
    ZeroCostBenchmarkComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-zero-cost-benchmark',
            template: __webpack_require__(/*! ./zero-cost-benchmark.component.html */ "./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.html"),
            styles: [__webpack_require__(/*! ./zero-cost-benchmark.component.css */ "./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], ZeroCostBenchmarkComponent);
    return ZeroCostBenchmarkComponent;
}());



/***/ }),

/***/ "./src/app/modules/services/services-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/modules/services/services-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: ServicesRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicesRoutingModule", function() { return ServicesRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _pages_zero_cost_benchmark_zero_cost_benchmark_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/zero-cost-benchmark/zero-cost-benchmark.component */ "./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.ts");
/* harmony import */ var _pages_implementtion_and_consulting_implementtion_and_consulting_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/implementtion-and-consulting/implementtion-and-consulting.component */ "./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.ts");
/* harmony import */ var _pages_development_and_technical_integration_development_and_technical_integration_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/development-and-technical-integration/development-and-technical-integration.component */ "./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.ts");
/* harmony import */ var _pages_support_support_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/support/support.component */ "./src/app/modules/services/pages/support/support.component.ts");
/* harmony import */ var _pages_staffing_solutions_staffing_solutions_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/staffing-solutions/staffing-solutions.component */ "./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.ts");








var routes = [
    {
        path: '',
        component: _pages_zero_cost_benchmark_zero_cost_benchmark_component__WEBPACK_IMPORTED_MODULE_3__["ZeroCostBenchmarkComponent"]
    },
    {
        path: 'ZeroCostBenchmark',
        component: _pages_zero_cost_benchmark_zero_cost_benchmark_component__WEBPACK_IMPORTED_MODULE_3__["ZeroCostBenchmarkComponent"]
    },
    {
        path: 'ImplementtionAndConsulting',
        component: _pages_implementtion_and_consulting_implementtion_and_consulting_component__WEBPACK_IMPORTED_MODULE_4__["ImplementtionAndConsultingComponent"]
    },
    {
        path: 'DevelopmentAndTechnicalintegration',
        component: _pages_development_and_technical_integration_development_and_technical_integration_component__WEBPACK_IMPORTED_MODULE_5__["DevelopmentAndTechnicalIntegrationComponent"]
    },
    {
        path: 'Support',
        component: _pages_support_support_component__WEBPACK_IMPORTED_MODULE_6__["SupportComponent"]
    },
    {
        path: 'StaffingSolutions',
        component: _pages_staffing_solutions_staffing_solutions_component__WEBPACK_IMPORTED_MODULE_7__["StaffingSolutionsComponent"]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    },
];
var ServicesRoutingModule = /** @class */ (function () {
    function ServicesRoutingModule() {
    }
    ServicesRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ServicesRoutingModule);
    return ServicesRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/services/services.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/modules/services/services.module.ts ***!
  \*****************************************************/
/*! exports provided: ServicesModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ServicesModule", function() { return ServicesModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _services_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./services-routing.module */ "./src/app/modules/services/services-routing.module.ts");
/* harmony import */ var _pages_zero_cost_benchmark_zero_cost_benchmark_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/zero-cost-benchmark/zero-cost-benchmark.component */ "./src/app/modules/services/pages/zero-cost-benchmark/zero-cost-benchmark.component.ts");
/* harmony import */ var _pages_implementtion_and_consulting_implementtion_and_consulting_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/implementtion-and-consulting/implementtion-and-consulting.component */ "./src/app/modules/services/pages/implementtion-and-consulting/implementtion-and-consulting.component.ts");
/* harmony import */ var _pages_development_and_technical_integration_development_and_technical_integration_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/development-and-technical-integration/development-and-technical-integration.component */ "./src/app/modules/services/pages/development-and-technical-integration/development-and-technical-integration.component.ts");
/* harmony import */ var _pages_support_support_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./pages/support/support.component */ "./src/app/modules/services/pages/support/support.component.ts");
/* harmony import */ var _pages_staffing_solutions_staffing_solutions_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./pages/staffing-solutions/staffing-solutions.component */ "./src/app/modules/services/pages/staffing-solutions/staffing-solutions.component.ts");









var ServicesModule = /** @class */ (function () {
    function ServicesModule() {
    }
    ServicesModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_pages_zero_cost_benchmark_zero_cost_benchmark_component__WEBPACK_IMPORTED_MODULE_4__["ZeroCostBenchmarkComponent"], _pages_implementtion_and_consulting_implementtion_and_consulting_component__WEBPACK_IMPORTED_MODULE_5__["ImplementtionAndConsultingComponent"], _pages_development_and_technical_integration_development_and_technical_integration_component__WEBPACK_IMPORTED_MODULE_6__["DevelopmentAndTechnicalIntegrationComponent"], _pages_support_support_component__WEBPACK_IMPORTED_MODULE_7__["SupportComponent"], _pages_staffing_solutions_staffing_solutions_component__WEBPACK_IMPORTED_MODULE_8__["StaffingSolutionsComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _services_routing_module__WEBPACK_IMPORTED_MODULE_3__["ServicesRoutingModule"]
            ]
        })
    ], ServicesModule);
    return ServicesModule;
}());



/***/ })

}]);
//# sourceMappingURL=src-app-modules-services-services-module.js.map