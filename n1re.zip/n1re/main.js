(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"src/app/modules/about/about.module": [
		"./src/app/modules/about/about.module.ts",
		"src-app-modules-about-about-module"
	],
	"src/app/modules/contact/contact.module": [
		"./src/app/modules/contact/contact.module.ts",
		"src-app-modules-contact-contact-module"
	],
	"src/app/modules/expertise/expertise.module": [
		"./src/app/modules/expertise/expertise.module.ts",
		"src-app-modules-expertise-expertise-module"
	],
	"src/app/modules/home/home.module": [
		"./src/app/modules/home/home.module.ts",
		"src-app-modules-home-home-module"
	],
	"src/app/modules/services/services.module": [
		"./src/app/modules/services/services.module.ts",
		"src-app-modules-services-services-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _shared_moduleRout_moduleRout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./shared/moduleRout/moduleRout */ "./src/app/shared/moduleRout/moduleRout.ts");




var routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full',
    },
    {
        path: '',
        children: _shared_moduleRout_moduleRout__WEBPACK_IMPORTED_MODULE_3__["moduleRoutes"]
    },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { useHash: true })],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<app-header></app-header>\n<router-outlet></router-outlet>\n<app-footer></app-footer>"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var AppComponent = /** @class */ (function () {
    function AppComponent() {
        this.title = 'n1re';
    }
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        })
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser/animations */ "./node_modules/@angular/platform-browser/fesm5/animations.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./shared */ "./src/app/shared/index.ts");
/* harmony import */ var _shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");









var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"],
                _shared__WEBPACK_IMPORTED_MODULE_6__["HeaderComponent"],
                _shared__WEBPACK_IMPORTED_MODULE_6__["FooterComponent"],
            ],
            imports: [
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"],
                _app_routing_module__WEBPACK_IMPORTED_MODULE_4__["AppRoutingModule"],
                _shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"],
                _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_3__["BrowserAnimationsModule"]
            ],
            providers: [{ provide: _angular_common__WEBPACK_IMPORTED_MODULE_8__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_8__["HashLocationStrategy"] }],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_5__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/shared/footer/footer.component.css":
/*!****************************************************!*\
  !*** ./src/app/shared/footer/footer.component.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "section {\r\n  width: 100%;\r\n  display: inline-block;\r\n  background: #333;\r\n  height: 50vh;\r\n  text-align: center;\r\n  font-size: 22px;\r\n  font-weight: 700;\r\n  text-decoration: underline;\r\n}\r\n\r\n.footer-distributed {\r\n  background: #151414;\r\n  box-shadow: 0 1px 1px 0 rgba(0, 0, 0, 0.12);\r\n  box-sizing: border-box;\r\n  width: 100%;\r\n  text-align: left;\r\n  font: bold 16px sans-serif;\r\n  padding: 55px 50px;\r\n}\r\n\r\n.footer-distributed .footer-left,\r\n.footer-distributed .footer-center,\r\n.footer-distributed .footer-right {\r\n  display: inline-block;\r\n  vertical-align: top;\r\n}\r\n\r\n/* Footer left */\r\n\r\n.footer-distributed .footer-left {\r\n  width: 40%;\r\n}\r\n\r\n/* The company logo */\r\n\r\n.footer-distributed h3 {\r\n  color: #ffffff;\r\n  font: normal 36px \"Open Sans\", cursive;\r\n  margin: 0;\r\n}\r\n\r\n.footer-distributed h3 span {\r\n  color: #4a90e2;\r\n}\r\n\r\n/* Footer links */\r\n\r\n.footer-distributed .footer-links {\r\n  color: #ffffff;\r\n  margin: 20px 0 12px;\r\n  padding: 0;\r\n}\r\n\r\n.footer-distributed .footer-links a {\r\n  display: inline-block;\r\n  line-height: 1.8;\r\n  font-weight: 400;\r\n  text-decoration: none;\r\n  color: inherit;\r\n}\r\n\r\n.footer-distributed .footer-company-name {\r\n  color: #498fe0;\r\n  font-size: 14px;\r\n  font-weight: normal;\r\n  margin: 0;\r\n}\r\n\r\n/* Footer Center */\r\n\r\n.footer-distributed .footer-center {\r\n  width: 35%;\r\n}\r\n\r\n.footer-distributed .footer-center i {\r\n  background-color: #33383b;\r\n  color: #ffffff;\r\n  font-size: 25px;\r\n  width: 38px;\r\n  height: 38px;\r\n  border-radius: 50%;\r\n  text-align: center;\r\n  line-height: 42px;\r\n  margin: 10px 15px;\r\n  vertical-align: middle;\r\n}\r\n\r\n.footer-distributed .footer-center i.fa-envelope {\r\n  font-size: 17px;\r\n  line-height: 38px;\r\n}\r\n\r\n.footer-distributed .footer-center p {\r\n  display: inline-block;\r\n  color: #92999f;\r\n  font-weight: 400;\r\n  vertical-align: middle;\r\n  margin: 0;\r\n  font-size: 14px;\r\n}\r\n\r\n.footer-distributed .footer-center p span {\r\n  display: block;\r\n  font-weight: normal;\r\n  font-size: 14px;\r\n  line-height: 2;\r\n}\r\n\r\n.footer-distributed .footer-center p a {\r\n  color: #92999f;\r\n  text-decoration: none;\r\n  font-size: 14px;\r\n}\r\n\r\n.footer-distributed .footer-links a:before {\r\n  content: \"|\";\r\n  font-weight: 300;\r\n  font-size: 20px;\r\n  left: 0;\r\n  color: #fff;\r\n  display: inline-block;\r\n  padding-right: 5px;\r\n}\r\n\r\n.footer-distributed .footer-links .link-1:before {\r\n  content: none;\r\n}\r\n\r\n/* Footer Right */\r\n\r\n.footer-distributed .footer-right {\r\n  width: 20%;\r\n}\r\n\r\n.footer-distributed .footer-company-about {\r\n  line-height: 20px;\r\n  color: #92999f;\r\n  font-size: 14px;\r\n  font-weight: normal;\r\n  margin: 0;\r\n}\r\n\r\n.footer-distributed .footer-company-about span {\r\n  display: block;\r\n  color: #ffffff;\r\n  font-size: 14px;\r\n  font-weight: bold;\r\n  margin-bottom: 20px;\r\n}\r\n\r\n.footer-distributed .footer-icons {\r\n  margin-top: 25px;\r\n}\r\n\r\n.footer-distributed .footer-icons a {\r\n  display: inline-block;\r\n  width: 35px;\r\n  height: 35px;\r\n  cursor: pointer;\r\n  background-color: #33383b;\r\n  border-radius: 2px;\r\n\r\n  font-size: 20px;\r\n  color: #ffffff;\r\n  text-align: center;\r\n  line-height: 35px;\r\n\r\n  margin-right: 3px;\r\n  margin-bottom: 5px;\r\n}\r\n\r\n.copyright-area{\r\n    background: #202020;\r\n    padding: 25px 0;\r\n  }\r\n\r\n.copyright-text p {\r\n    margin: 0;\r\n    font-size: 14px;\r\n    color: #878787;\r\n  }\r\n\r\n.copyright-text p a{\r\n    color: #498fe0;\r\n  }\r\n\r\n.footer-menu li {\r\n    display: inline-block;\r\n    margin-left: 20px;\r\n  }\r\n\r\n.footer-menu li:hover a{\r\n    color: #498fe0;\r\n  }\r\n\r\n.footer-menu li a {\r\n    font-size: 14px;\r\n    color: #878787;\r\n  }\r\n\r\n.gotop {\r\n  position: fixed;\r\n  bottom: 5px;\r\n  right: 5px;\r\n  font-size: 18px;\r\n  text-align: center;\r\n  border-radius: 50px;\r\n  outline: none;\r\n  border: none;\r\n  padding: 10px;\r\n  z-index: 9;\r\n  background-color: transparent;\r\n}\r\n\r\n@-webkit-keyframes bounce {\r\n  0%,\r\n  20%,\r\n  50%,\r\n  80%,\r\n  100% {\r\n    -webkit-transform: translateY(0);\r\n    transform: translateY(0);\r\n  }\r\n  40% {\r\n    -webkit-transform: translateY(-30px);\r\n    transform: translateY(-30px);\r\n  }\r\n  60% {\r\n    -webkit-transform: translateY(-15px);\r\n    transform: translateY(-15px);\r\n  }\r\n}\r\n\r\n@keyframes bounce {\r\n  0%,\r\n  20%,\r\n  50%,\r\n  80%,\r\n  100% {\r\n    -webkit-transform: translateY(0);\r\n    transform: translateY(0);\r\n  }\r\n  40% {\r\n    -webkit-transform: translateY(-30px);\r\n    transform: translateY(-30px);\r\n  }\r\n  60% {\r\n    -webkit-transform: translateY(-15px);\r\n    transform: translateY(-15px);\r\n  }\r\n}\r\n\r\n.bounce {\r\n  -webkit-animation: bounce 2s infinite;\r\n  animation: bounce 2s infinite;\r\n}\r\n\r\n/* If you don't want the footer to be responsive, remove these media queries */\r\n\r\n@media (max-width: 880px) {\r\n  .footer-distributed {\r\n    font: bold 14px sans-serif;\r\n  }\r\n\r\n  .footer-distributed .footer-left,\r\n  .footer-distributed .footer-center,\r\n  .footer-distributed .footer-right {\r\n    display: block;\r\n    width: 100%;\r\n    margin-bottom: 40px;\r\n    text-align: center;\r\n  }\r\n\r\n  .footer-distributed .footer-center i {\r\n    margin-left: 0;\r\n  }\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2Zvb3Rlci9mb290ZXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFdBQVc7RUFDWCxxQkFBcUI7RUFDckIsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQiwwQkFBMEI7QUFDNUI7O0FBRUE7RUFDRSxtQkFBbUI7RUFDbkIsMkNBQTJDO0VBQzNDLHNCQUFzQjtFQUN0QixXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLDBCQUEwQjtFQUMxQixrQkFBa0I7QUFDcEI7O0FBRUE7OztFQUdFLHFCQUFxQjtFQUNyQixtQkFBbUI7QUFDckI7O0FBRUEsZ0JBQWdCOztBQUVoQjtFQUNFLFVBQVU7QUFDWjs7QUFFQSxxQkFBcUI7O0FBRXJCO0VBQ0UsY0FBYztFQUNkLHNDQUFzQztFQUN0QyxTQUFTO0FBQ1g7O0FBRUE7RUFDRSxjQUFjO0FBQ2hCOztBQUVBLGlCQUFpQjs7QUFFakI7RUFDRSxjQUFjO0VBQ2QsbUJBQW1CO0VBQ25CLFVBQVU7QUFDWjs7QUFFQTtFQUNFLHFCQUFxQjtFQUNyQixnQkFBZ0I7RUFDaEIsZ0JBQWdCO0VBQ2hCLHFCQUFxQjtFQUNyQixjQUFjO0FBQ2hCOztBQUVBO0VBQ0UsY0FBYztFQUNkLGVBQWU7RUFDZixtQkFBbUI7RUFDbkIsU0FBUztBQUNYOztBQUVBLGtCQUFrQjs7QUFFbEI7RUFDRSxVQUFVO0FBQ1o7O0FBRUE7RUFDRSx5QkFBeUI7RUFDekIsY0FBYztFQUNkLGVBQWU7RUFDZixXQUFXO0VBQ1gsWUFBWTtFQUNaLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsaUJBQWlCO0VBQ2pCLGlCQUFpQjtFQUNqQixzQkFBc0I7QUFDeEI7O0FBRUE7RUFDRSxlQUFlO0VBQ2YsaUJBQWlCO0FBQ25COztBQUVBO0VBQ0UscUJBQXFCO0VBQ3JCLGNBQWM7RUFDZCxnQkFBZ0I7RUFDaEIsc0JBQXNCO0VBQ3RCLFNBQVM7RUFDVCxlQUFlO0FBQ2pCOztBQUVBO0VBQ0UsY0FBYztFQUNkLG1CQUFtQjtFQUNuQixlQUFlO0VBQ2YsY0FBYztBQUNoQjs7QUFFQTtFQUNFLGNBQWM7RUFDZCxxQkFBcUI7RUFDckIsZUFBZTtBQUNqQjs7QUFFQTtFQUNFLFlBQVk7RUFDWixnQkFBZ0I7RUFDaEIsZUFBZTtFQUNmLE9BQU87RUFDUCxXQUFXO0VBQ1gscUJBQXFCO0VBQ3JCLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGFBQWE7QUFDZjs7QUFFQSxpQkFBaUI7O0FBRWpCO0VBQ0UsVUFBVTtBQUNaOztBQUVBO0VBQ0UsaUJBQWlCO0VBQ2pCLGNBQWM7RUFDZCxlQUFlO0VBQ2YsbUJBQW1CO0VBQ25CLFNBQVM7QUFDWDs7QUFFQTtFQUNFLGNBQWM7RUFDZCxjQUFjO0VBQ2QsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQixtQkFBbUI7QUFDckI7O0FBRUE7RUFDRSxnQkFBZ0I7QUFDbEI7O0FBRUE7RUFDRSxxQkFBcUI7RUFDckIsV0FBVztFQUNYLFlBQVk7RUFDWixlQUFlO0VBQ2YseUJBQXlCO0VBQ3pCLGtCQUFrQjs7RUFFbEIsZUFBZTtFQUNmLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIsaUJBQWlCOztFQUVqQixpQkFBaUI7RUFDakIsa0JBQWtCO0FBQ3BCOztBQUVBO0lBQ0ksbUJBQW1CO0lBQ25CLGVBQWU7RUFDakI7O0FBQ0E7SUFDRSxTQUFTO0lBQ1QsZUFBZTtJQUNmLGNBQWM7RUFDaEI7O0FBQ0E7SUFDRSxjQUFjO0VBQ2hCOztBQUNBO0lBQ0UscUJBQXFCO0lBQ3JCLGlCQUFpQjtFQUNuQjs7QUFDQTtJQUNFLGNBQWM7RUFDaEI7O0FBQ0E7SUFDRSxlQUFlO0lBQ2YsY0FBYztFQUNoQjs7QUFFRjtFQUNFLGVBQWU7RUFDZixXQUFXO0VBQ1gsVUFBVTtFQUNWLGVBQWU7RUFDZixrQkFBa0I7RUFDbEIsbUJBQW1CO0VBQ25CLGFBQWE7RUFDYixZQUFZO0VBQ1osYUFBYTtFQUNiLFVBQVU7RUFDViw2QkFBNkI7QUFDL0I7O0FBb0JBO0VBQ0U7Ozs7O0lBS0UsZ0NBQWdDO0lBQ2hDLHdCQUF3QjtFQUMxQjtFQUNBO0lBQ0Usb0NBQW9DO0lBQ3BDLDRCQUE0QjtFQUM5QjtFQUNBO0lBQ0Usb0NBQW9DO0lBQ3BDLDRCQUE0QjtFQUM5QjtBQUNGOztBQUVBO0VBQ0U7Ozs7O0lBT0UsZ0NBQWdDO0lBQ2hDLHdCQUF3QjtFQUMxQjtFQUNBO0lBR0Usb0NBQW9DO0lBQ3BDLDRCQUE0QjtFQUM5QjtFQUNBO0lBR0Usb0NBQW9DO0lBQ3BDLDRCQUE0QjtFQUM5QjtBQUNGOztBQUVBO0VBRUUscUNBQXFDO0VBQ3JDLDZCQUE2QjtBQUMvQjs7QUFFQSw4RUFBOEU7O0FBRTlFO0VBQ0U7SUFDRSwwQkFBMEI7RUFDNUI7O0VBRUE7OztJQUdFLGNBQWM7SUFDZCxXQUFXO0lBQ1gsbUJBQW1CO0lBQ25CLGtCQUFrQjtFQUNwQjs7RUFFQTtJQUNFLGNBQWM7RUFDaEI7QUFDRiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9mb290ZXIvZm9vdGVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJzZWN0aW9uIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgYmFja2dyb3VuZDogIzMzMztcclxuICBoZWlnaHQ6IDUwdmg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtc2l6ZTogMjJweDtcclxuICBmb250LXdlaWdodDogNzAwO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogdW5kZXJsaW5lO1xyXG59XHJcblxyXG4uZm9vdGVyLWRpc3RyaWJ1dGVkIHtcclxuICBiYWNrZ3JvdW5kOiAjMTUxNDE0O1xyXG4gIGJveC1zaGFkb3c6IDAgMXB4IDFweCAwIHJnYmEoMCwgMCwgMCwgMC4xMik7XHJcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICB3aWR0aDogMTAwJTtcclxuICB0ZXh0LWFsaWduOiBsZWZ0O1xyXG4gIGZvbnQ6IGJvbGQgMTZweCBzYW5zLXNlcmlmO1xyXG4gIHBhZGRpbmc6IDU1cHggNTBweDtcclxufVxyXG5cclxuLmZvb3Rlci1kaXN0cmlidXRlZCAuZm9vdGVyLWxlZnQsXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1jZW50ZXIsXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1yaWdodCB7XHJcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gIHZlcnRpY2FsLWFsaWduOiB0b3A7XHJcbn1cclxuXHJcbi8qIEZvb3RlciBsZWZ0ICovXHJcblxyXG4uZm9vdGVyLWRpc3RyaWJ1dGVkIC5mb290ZXItbGVmdCB7XHJcbiAgd2lkdGg6IDQwJTtcclxufVxyXG5cclxuLyogVGhlIGNvbXBhbnkgbG9nbyAqL1xyXG5cclxuLmZvb3Rlci1kaXN0cmlidXRlZCBoMyB7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgZm9udDogbm9ybWFsIDM2cHggXCJPcGVuIFNhbnNcIiwgY3Vyc2l2ZTtcclxuICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgaDMgc3BhbiB7XHJcbiAgY29sb3I6ICM0YTkwZTI7XHJcbn1cclxuXHJcbi8qIEZvb3RlciBsaW5rcyAqL1xyXG5cclxuLmZvb3Rlci1kaXN0cmlidXRlZCAuZm9vdGVyLWxpbmtzIHtcclxuICBjb2xvcjogI2ZmZmZmZjtcclxuICBtYXJnaW46IDIwcHggMCAxMnB4O1xyXG4gIHBhZGRpbmc6IDA7XHJcbn1cclxuXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1saW5rcyBhIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgbGluZS1oZWlnaHQ6IDEuODtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICBjb2xvcjogaW5oZXJpdDtcclxufVxyXG5cclxuLmZvb3Rlci1kaXN0cmlidXRlZCAuZm9vdGVyLWNvbXBhbnktbmFtZSB7XHJcbiAgY29sb3I6ICM0OThmZTA7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgbWFyZ2luOiAwO1xyXG59XHJcblxyXG4vKiBGb290ZXIgQ2VudGVyICovXHJcblxyXG4uZm9vdGVyLWRpc3RyaWJ1dGVkIC5mb290ZXItY2VudGVyIHtcclxuICB3aWR0aDogMzUlO1xyXG59XHJcblxyXG4uZm9vdGVyLWRpc3RyaWJ1dGVkIC5mb290ZXItY2VudGVyIGkge1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICMzMzM4M2I7XHJcbiAgY29sb3I6ICNmZmZmZmY7XHJcbiAgZm9udC1zaXplOiAyNXB4O1xyXG4gIHdpZHRoOiAzOHB4O1xyXG4gIGhlaWdodDogMzhweDtcclxuICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGxpbmUtaGVpZ2h0OiA0MnB4O1xyXG4gIG1hcmdpbjogMTBweCAxNXB4O1xyXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbn1cclxuXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1jZW50ZXIgaS5mYS1lbnZlbG9wZSB7XHJcbiAgZm9udC1zaXplOiAxN3B4O1xyXG4gIGxpbmUtaGVpZ2h0OiAzOHB4O1xyXG59XHJcblxyXG4uZm9vdGVyLWRpc3RyaWJ1dGVkIC5mb290ZXItY2VudGVyIHAge1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBjb2xvcjogIzkyOTk5ZjtcclxuICBmb250LXdlaWdodDogNDAwO1xyXG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XHJcbiAgbWFyZ2luOiAwO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLmZvb3Rlci1kaXN0cmlidXRlZCAuZm9vdGVyLWNlbnRlciBwIHNwYW4ge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgZm9udC1zaXplOiAxNHB4O1xyXG4gIGxpbmUtaGVpZ2h0OiAyO1xyXG59XHJcblxyXG4uZm9vdGVyLWRpc3RyaWJ1dGVkIC5mb290ZXItY2VudGVyIHAgYSB7XHJcbiAgY29sb3I6ICM5Mjk5OWY7XHJcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxufVxyXG5cclxuLmZvb3Rlci1kaXN0cmlidXRlZCAuZm9vdGVyLWxpbmtzIGE6YmVmb3JlIHtcclxuICBjb250ZW50OiBcInxcIjtcclxuICBmb250LXdlaWdodDogMzAwO1xyXG4gIGZvbnQtc2l6ZTogMjBweDtcclxuICBsZWZ0OiAwO1xyXG4gIGNvbG9yOiAjZmZmO1xyXG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICBwYWRkaW5nLXJpZ2h0OiA1cHg7XHJcbn1cclxuXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1saW5rcyAubGluay0xOmJlZm9yZSB7XHJcbiAgY29udGVudDogbm9uZTtcclxufVxyXG5cclxuLyogRm9vdGVyIFJpZ2h0ICovXHJcblxyXG4uZm9vdGVyLWRpc3RyaWJ1dGVkIC5mb290ZXItcmlnaHQge1xyXG4gIHdpZHRoOiAyMCU7XHJcbn1cclxuXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1jb21wYW55LWFib3V0IHtcclxuICBsaW5lLWhlaWdodDogMjBweDtcclxuICBjb2xvcjogIzkyOTk5ZjtcclxuICBmb250LXNpemU6IDE0cHg7XHJcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcclxuICBtYXJnaW46IDA7XHJcbn1cclxuXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1jb21wYW55LWFib3V0IHNwYW4ge1xyXG4gIGRpc3BsYXk6IGJsb2NrO1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG4gIGZvbnQtc2l6ZTogMTRweDtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG59XHJcblxyXG4uZm9vdGVyLWRpc3RyaWJ1dGVkIC5mb290ZXItaWNvbnMge1xyXG4gIG1hcmdpbi10b3A6IDI1cHg7XHJcbn1cclxuXHJcbi5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1pY29ucyBhIHtcclxuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgd2lkdGg6IDM1cHg7XHJcbiAgaGVpZ2h0OiAzNXB4O1xyXG4gIGN1cnNvcjogcG9pbnRlcjtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzODNiO1xyXG4gIGJvcmRlci1yYWRpdXM6IDJweDtcclxuXHJcbiAgZm9udC1zaXplOiAyMHB4O1xyXG4gIGNvbG9yOiAjZmZmZmZmO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBsaW5lLWhlaWdodDogMzVweDtcclxuXHJcbiAgbWFyZ2luLXJpZ2h0OiAzcHg7XHJcbiAgbWFyZ2luLWJvdHRvbTogNXB4O1xyXG59XHJcblxyXG4uY29weXJpZ2h0LWFyZWF7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMjAyMDIwO1xyXG4gICAgcGFkZGluZzogMjVweCAwO1xyXG4gIH1cclxuICAuY29weXJpZ2h0LXRleHQgcCB7XHJcbiAgICBtYXJnaW46IDA7XHJcbiAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICBjb2xvcjogIzg3ODc4NztcclxuICB9XHJcbiAgLmNvcHlyaWdodC10ZXh0IHAgYXtcclxuICAgIGNvbG9yOiAjNDk4ZmUwO1xyXG4gIH1cclxuICAuZm9vdGVyLW1lbnUgbGkge1xyXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDIwcHg7XHJcbiAgfVxyXG4gIC5mb290ZXItbWVudSBsaTpob3ZlciBhe1xyXG4gICAgY29sb3I6ICM0OThmZTA7XHJcbiAgfVxyXG4gIC5mb290ZXItbWVudSBsaSBhIHtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGNvbG9yOiAjODc4Nzg3O1xyXG4gIH1cclxuXHJcbi5nb3RvcCB7XHJcbiAgcG9zaXRpb246IGZpeGVkO1xyXG4gIGJvdHRvbTogNXB4O1xyXG4gIHJpZ2h0OiA1cHg7XHJcbiAgZm9udC1zaXplOiAxOHB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBib3JkZXItcmFkaXVzOiA1MHB4O1xyXG4gIG91dGxpbmU6IG5vbmU7XHJcbiAgYm9yZGVyOiBub25lO1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgei1pbmRleDogOTtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcclxufVxyXG5ALW1vei1rZXlmcmFtZXMgYm91bmNlIHtcclxuICAwJSxcclxuICAyMCUsXHJcbiAgNTAlLFxyXG4gIDgwJSxcclxuICAxMDAlIHtcclxuICAgIC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApO1xyXG4gIH1cclxuICA0MCUge1xyXG4gICAgLW1vei10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTMwcHgpO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0zMHB4KTtcclxuICB9XHJcbiAgNjAlIHtcclxuICAgIC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xNXB4KTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMTVweCk7XHJcbiAgfVxyXG59XHJcblxyXG5ALXdlYmtpdC1rZXlmcmFtZXMgYm91bmNlIHtcclxuICAwJSxcclxuICAyMCUsXHJcbiAgNTAlLFxyXG4gIDgwJSxcclxuICAxMDAlIHtcclxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDApO1xyXG4gIH1cclxuICA0MCUge1xyXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTMwcHgpO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0zMHB4KTtcclxuICB9XHJcbiAgNjAlIHtcclxuICAgIC13ZWJraXQtdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xNXB4KTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgtMTVweCk7XHJcbiAgfVxyXG59XHJcblxyXG5Aa2V5ZnJhbWVzIGJvdW5jZSB7XHJcbiAgMCUsXHJcbiAgMjAlLFxyXG4gIDUwJSxcclxuICA4MCUsXHJcbiAgMTAwJSB7XHJcbiAgICAtbW96LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTtcclxuICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMCk7XHJcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTtcclxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgwKTtcclxuICB9XHJcbiAgNDAlIHtcclxuICAgIC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0zMHB4KTtcclxuICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTMwcHgpO1xyXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTMwcHgpO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0zMHB4KTtcclxuICB9XHJcbiAgNjAlIHtcclxuICAgIC1tb3otdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xNXB4KTtcclxuICAgIC1tcy10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTE1cHgpO1xyXG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTE1cHgpO1xyXG4gICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKC0xNXB4KTtcclxuICB9XHJcbn1cclxuXHJcbi5ib3VuY2Uge1xyXG4gIC1tb3otYW5pbWF0aW9uOiBib3VuY2UgMnMgaW5maW5pdGU7XHJcbiAgLXdlYmtpdC1hbmltYXRpb246IGJvdW5jZSAycyBpbmZpbml0ZTtcclxuICBhbmltYXRpb246IGJvdW5jZSAycyBpbmZpbml0ZTtcclxufVxyXG5cclxuLyogSWYgeW91IGRvbid0IHdhbnQgdGhlIGZvb3RlciB0byBiZSByZXNwb25zaXZlLCByZW1vdmUgdGhlc2UgbWVkaWEgcXVlcmllcyAqL1xyXG5cclxuQG1lZGlhIChtYXgtd2lkdGg6IDg4MHB4KSB7XHJcbiAgLmZvb3Rlci1kaXN0cmlidXRlZCB7XHJcbiAgICBmb250OiBib2xkIDE0cHggc2Fucy1zZXJpZjtcclxuICB9XHJcblxyXG4gIC5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1sZWZ0LFxyXG4gIC5mb290ZXItZGlzdHJpYnV0ZWQgLmZvb3Rlci1jZW50ZXIsXHJcbiAgLmZvb3Rlci1kaXN0cmlidXRlZCAuZm9vdGVyLXJpZ2h0IHtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tYm90dG9tOiA0MHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIH1cclxuXHJcbiAgLmZvb3Rlci1kaXN0cmlidXRlZCAuZm9vdGVyLWNlbnRlciBpIHtcclxuICAgIG1hcmdpbi1sZWZ0OiAwO1xyXG4gIH1cclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/shared/footer/footer.component.html":
/*!*****************************************************!*\
  !*** ./src/app/shared/footer/footer.component.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--<section class=\"w3l-footer-29-main\">\n  <div class=\"footer-29\">\n      <div class=\"wrapper\">\n          <div class=\"d-grid grid-col-4 footer-top-29\">\n              <div class=\"footer-list-29 footer-1\">\n                  <h6 class=\"footer-title-29\">Contact Us</h6>\n                  <ul>\n                      <li><p><span class=\"fa fa-map-marker\"></span> n1re ,\n                        86/80, 4th Floor, SGR Plaza,\n                        Old Airport Road, Marathahalli,\n                        BENGALURU - 560037,\n                        Karnataka, India</p></li>\n                      <li><a href=\"tel:+91-7406272111\"><span class=\"fa fa-phone\"></span> +91-7406272111</a></li>\n                      <li><a href=\"mailto:info@n1re.com\" class=\"mail\"><span class=\"fa fa-envelope-open-o\"></span> info@n1re.com</a></li>\n                      <li><a href=\"mailto:contact@n1re.com\" class=\"mail\"><span class=\"fa fa-envelope-open-o\"></span> contact@n1re.com</a></li>\n                  </ul>\n                  <div class=\"main-social-footer-29\">\n                      <a href=\"#facebook\" class=\"facebook\"><span class=\"fa fa-facebook\"></span></a>\n                      <a href=\"#twitter\" class=\"twitter\"><span class=\"fa fa-twitter\"></span></a>\n                      <a href=\"#instagram\" class=\"instagram\"><span class=\"fa fa-instagram\"></span></a>\n                      <a href=\"#google-plus\" class=\"google-plus\"><span class=\"fa fa-google-plus\"></span></a>\n                      <a href=\"#linkedin\" class=\"linkedin\"><span class=\"fa fa-linkedin\"></span></a>\n                  </div>\n              </div>\n              <div class=\"footer-list-29 footer-2\">\n                  <ul>\n                      <h6 class=\"footer-title-29\">Work Flows</h6>\n                      <li><a href=\"single.html\">Management</a></li>\n                      <li><a href=\"single.html\">Reporting</a></li>\n                      <li><a href=\"single.html\">Tracking</a></li>\n                      <li><a href=\"login.html\">All Users</a></li>\n                      <li><a href=\"contact.html\">Support</a></li>\n                  </ul>\n              </div>\n              <div class=\"footer-list-29 footer-3\">\n                  <div class=\"properties\">\n                      <h6 class=\"footer-title-29\">Recent Post</h6>\n                      \n                  </div>\n              </div>\n              <div class=\"footer-list-29 footer-4\">\n                  <ul>\n                      <h6 class=\"footer-title-29\">Quick Links</h6>\n                      <li><a href=\"home.html\">Home</a></li>\n                      <li><a href=\"about.html\">About</a></li>\n                      <li><a href=\"services.html\">Services</a></li>\n                      <li><a href=\"blog.html\"> Blog</a></li>\n                      <li><a href=\"contact.html\">Contact</a></li>\n                  </ul>\n              </div>\n          </div>\n          <div class=\"d-grid grid-col-2 bottom-copies\">\n              <p class=\"copy-footer-29\">© 2016 n1re. All rights reserved</p>\n               <ul class=\"list-btm-29\">\n                      <li><a href=\"#link\">Privacy policy</a></li>\n                      <li><a href=\"#link\">Terms of service</a></li>\n                  </ul>\n          </div>\n      </div>\n  </div>\n</section>-->\n\n<footer class=\"footer-distributed\">\n\n    <div class=\"container\">\n        <div class=\"footer-left\">\n            <h1> <a style=\"color: #17c0eb;\" class=\"navbar-brand\" routerLink=\"/home\"><span>n</span>1re</a>\n            </h1>\n            <!-- <img alt=\"Your logo\" src=\"assets/images/header/n1re.png\" title=\"Your logo\"> -->\n            <!--<p class=\"footer-links\">\n            <a href=\"#\" class=\"link-1\">Home</a>\n\n            <a href=\"#\">Blog</a>\n\n            <a href=\"#\">Pricing</a>\n\n            <a href=\"#\">About</a>\n\n            <a href=\"#\">Faq</a>\n\n            <a href=\"#\">Contact</a>\n        </p>-->\n            <p style=\"color: #92999f;\n        font-size: 14px;\n        font-weight: normal;\"> <b>Corporate Office</b> <br>  Raheja Towers, 10th Floor,  West Wing, <br> M G Road Bangalore, <br> KA - 560001\n            </p>\n\n            <!-- <p class=\"footer-company-name\">2016 © n1re. All rights Reserved</p>-->\n        </div>\n\n        <div class=\"footer-center\">\n\n            <div>\n                <i class=\"fa fa-phone\"></i>\n                <p><a href=\"tel:+44-078-774-67872\">09731313194</a></p>\n            </div>\n\n            <div>\n                <i class=\"fa fa-envelope\"></i>\n                <p><a href=\"mailto:info@n1re.com\">info@n1re.com</a></p>\n            </div>\n\n            <div>\n                <i class=\"fa fa-envelope\"></i>\n                <p><a href=\"mailto:contact@n1re.com\">contact@n1re.com</a></p>\n            </div>\n\n        </div>\n\n        <div class=\"footer-right\">\n\n            <p class=\"footer-company-about\">\n                <span>About the company</span>\n                n1re provides comprehensive solutions and services that meet and exceed the property needs and goals\n                of our clients. And its our responsibility to offer you a great property.\n            </p>\n\n        <!--    <div class=\"footer-icons\">\n                <a href=\"#\"><i class=\"fa fa-facebook\"></i></a>\n                <a href=\"#\"><i class=\"fa fa-twitter\"></i></a>\n                <a href=\"#\"><i class=\"fa fa-linkedin\"></i></a>\n                <a href=\"#\"><i class=\"fa fa-github\"></i></a>\n            </div>\n        -->\n\n        </div>\n    </div>\n\n</footer>\n<div class=\"copyright-area\">\n    <div class=\"container\">\n        <div class=\"row\">\n            <div class=\"col-xl-8 col-lg-8 text-center text-lg-left\">\n                <div class=\"copyright-text\">\n                    <p>Copyright © 2020, All Right Reserved <a (click)=\"gotoTop()\" routerLink=\"/home\"> N1 Real Estate </a></p>\n                </div>\n            </div>\n            <div class=\"col-xl-4 col-lg-4 d-none d-lg-block text-right\">\n                <div class=\"footer-menu\">\n                    <ul>\n                        <li (click)=\"gotoTop()\"><a routerLink=\"/home\">Home</a></li>\n                        <li (click)=\"gotoTop()\"><a routerLink=\"/about\">About Us</a></li>\n                        <li (click)=\"gotoTop()\"><a routerLink=\"/about/package\">Why Us</a></li>\n                        <li (click)=\"gotoTop()\"><a routerLink=\"/contact\">Contact</a></li>\n                    </ul>\n                </div>\n            </div>\n        </div>\n    </div>\n</div>\n<button class=\"gotop\" *ngIf=\"isShow\" (click)=\"gotoTop()\">\n    <img src=\"assets/images/footer/up.png\" class=\"img-responsive bounce\" alt=\"up\">\n</button>"

/***/ }),

/***/ "./src/app/shared/footer/footer.component.ts":
/*!***************************************************!*\
  !*** ./src/app/shared/footer/footer.component.ts ***!
  \***************************************************/
/*! exports provided: FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return FooterComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var FooterComponent = /** @class */ (function () {
    function FooterComponent() {
        this.topPosToStartShowing = 100;
    }
    FooterComponent.prototype.checkScroll = function () {
        // scroll top
        // Both window.pageYOffset and document.documentElement.scrollTop returns the same result in all the cases. window.pageYOffset is not supported below IE 9.
        var scrollPosition = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;
        // console.log('[scroll]', scrollPosition);
        if (scrollPosition >= this.topPosToStartShowing) {
            this.isShow = true;
        }
        else {
            this.isShow = false;
        }
    };
    FooterComponent.prototype.gotoTop = function () {
        window.scroll({
            top: 0,
            left: 0,
            behavior: 'smooth'
        });
    };
    FooterComponent.prototype.ngOnInit = function () {
    };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["HostListener"])('window:scroll'),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Function),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", []),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:returntype", void 0)
    ], FooterComponent.prototype, "checkScroll", null);
    FooterComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-footer',
            template: __webpack_require__(/*! ./footer.component.html */ "./src/app/shared/footer/footer.component.html"),
            styles: [__webpack_require__(/*! ./footer.component.css */ "./src/app/shared/footer/footer.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], FooterComponent);
    return FooterComponent;
}());



/***/ }),

/***/ "./src/app/shared/header/header.component.css":
/*!****************************************************!*\
  !*** ./src/app/shared/header/header.component.css ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "header {\r\n    position: -webkit-sticky;\r\n    position: sticky;\r\n    z-index: 9;\r\n    width: 100%;\r\n    top: 0;\r\n    box-shadow: 0 0.15rem 0.1rem 0 rgba(0, 0, 0, 0.05);\r\n    background-color: #fff;\r\n}\r\n.pb-3, .py-3 {\r\n    padding-bottom: 1rem !important;\r\n    padding-top: 15px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL2hlYWRlci9oZWFkZXIuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtJQUNJLHdCQUFnQjtJQUFoQixnQkFBZ0I7SUFDaEIsVUFBVTtJQUNWLFdBQVc7SUFDWCxNQUFNO0lBRU4sa0RBQWtEO0lBQ2xELHNCQUFzQjtBQUMxQjtBQUNBO0lBQ0ksK0JBQStCO0lBQy9CLGlCQUFpQjtBQUNyQiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlZC9oZWFkZXIvaGVhZGVyLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyJoZWFkZXIge1xyXG4gICAgcG9zaXRpb246IHN0aWNreTtcclxuICAgIHotaW5kZXg6IDk7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHRvcDogMDtcclxuICAgIC13ZWJraXQtYm94LXNoYWRvdzogMCAwLjE1cmVtIDAuMXJlbSAwIHJnYmEoMCwgMCwgMCwgMC4wNSk7XHJcbiAgICBib3gtc2hhZG93OiAwIDAuMTVyZW0gMC4xcmVtIDAgcmdiYSgwLCAwLCAwLCAwLjA1KTtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7XHJcbn1cclxuLnBiLTMsIC5weS0zIHtcclxuICAgIHBhZGRpbmctYm90dG9tOiAxcmVtICFpbXBvcnRhbnQ7XHJcbiAgICBwYWRkaW5nLXRvcDogMTVweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/shared/header/header.component.html":
/*!*****************************************************!*\
  !*** ./src/app/shared/header/header.component.html ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<header class=\"header\">\n    <div class=\"container\">\n        <!-- nav -->\n        <nav class=\"pb-3\">\n            <div id=\"logo\">\n                <h1> <a class=\"navbar-brand\" routerLink=\"/home\"><span>n</span>1re</a>\n                </h1>\n            </div>\n            <label for=\"drop\" class=\"toggle\">Menu</label>\n            <input type=\"checkbox\" id=\"drop\" />\n            <ul class=\"menu mt-2\">\n                <li [ngClass]=\"{'active': activeURL == '/home'}\"><a routerLink=\"/home\">Home</a></li>\n                <li [ngClass]=\"{'active': activeURL == '/about'}\"><a routerLink=\"/about\">About</a></li>\n                <li [ngClass]=\"{'active': activeURL == '/about/whyUs'}\"><a routerLink=\"/about/whyUs\">Why Us</a></li>\n                <li [ngClass]=\"{'active': activeURL == '/contact'}\"><a routerLink=\"/contact\">Contact</a>\n                </li>\n                <li class=\"header-right\">\n                    <a href=\"tel:+91-943-974-4847\" class=\"contact\"> <span class=\"fa fa-phone\"></span> 09731313194</a>\n                </li>\n            </ul>\n        </nav>\n        <!-- //nav -->\n    </div>\n</header>"

/***/ }),

/***/ "./src/app/shared/header/header.component.ts":
/*!***************************************************!*\
  !*** ./src/app/shared/header/header.component.ts ***!
  \***************************************************/
/*! exports provided: HeaderComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return HeaderComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var HeaderComponent = /** @class */ (function () {
    function HeaderComponent(router) {
        var _this = this;
        this.router = router;
        this.router.events.subscribe(function () {
            _this.activeURL = _this.router.url;
        });
    }
    HeaderComponent.prototype.ngOnInit = function () { };
    HeaderComponent.prototype.navigate = function () {
        this.router.navigateByUrl('home');
    };
    HeaderComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-header",
            template: __webpack_require__(/*! ./header.component.html */ "./src/app/shared/header/header.component.html"),
            styles: [__webpack_require__(/*! ./header.component.css */ "./src/app/shared/header/header.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], HeaderComponent);
    return HeaderComponent;
}());



/***/ }),

/***/ "./src/app/shared/index.ts":
/*!*********************************!*\
  !*** ./src/app/shared/index.ts ***!
  \*********************************/
/*! exports provided: HeaderComponent, FooterComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _header_header_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header/header.component */ "./src/app/shared/header/header.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "HeaderComponent", function() { return _header_header_component__WEBPACK_IMPORTED_MODULE_0__["HeaderComponent"]; });

/* harmony import */ var _footer_footer_component__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./footer/footer.component */ "./src/app/shared/footer/footer.component.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "FooterComponent", function() { return _footer_footer_component__WEBPACK_IMPORTED_MODULE_1__["FooterComponent"]; });





/***/ }),

/***/ "./src/app/shared/moduleRout/moduleRout.ts":
/*!*************************************************!*\
  !*** ./src/app/shared/moduleRout/moduleRout.ts ***!
  \*************************************************/
/*! exports provided: moduleRoutes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "moduleRoutes", function() { return moduleRoutes; });
var moduleRoutes = [
    { path: 'home', loadChildren: 'src/app/modules/home/home.module#HomeModule' },
    { path: 'about', loadChildren: 'src/app/modules/about/about.module#AboutModule' },
    { path: 'contact', loadChildren: 'src/app/modules/contact/contact.module#ContactModule' },
    { path: 'expertise', loadChildren: 'src/app/modules/expertise/expertise.module#ExpertiseModule' },
    { path: 'services', loadChildren: 'src/app/modules/services/services.module#ServicesModule' }
];


/***/ }),

/***/ "./src/app/shared/shared.module.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var ngx_owl_carousel_o__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ngx-owl-carousel-o */ "./node_modules/ngx-owl-carousel-o/fesm5/ngx-owl-carousel-o.js");




var SharedModule = /** @class */ (function () {
    function SharedModule() {
    }
    SharedModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], ngx_owl_carousel_o__WEBPACK_IMPORTED_MODULE_3__["CarouselModule"]
            ]
        })
    ], SharedModule);
    return SharedModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! D:\Akash\n1re\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map