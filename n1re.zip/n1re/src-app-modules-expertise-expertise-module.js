(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-modules-expertise-expertise-module"],{

/***/ "./src/app/modules/expertise/expertise-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/modules/expertise/expertise-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: ExpertiseRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExpertiseRoutingModule", function() { return ExpertiseRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _pages_warehouse_analytics_warehouse_analytics_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/warehouse-analytics/warehouse-analytics.component */ "./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.ts");
/* harmony import */ var _pages_warehouse_management_warehouse_management_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/warehouse-management/warehouse-management.component */ "./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.ts");





var routes = [
    {
        path: '',
        component: _pages_warehouse_management_warehouse_management_component__WEBPACK_IMPORTED_MODULE_4__["WarehouseManagementComponent"]
    },
    {
        path: 'WarehouseManagement',
        component: _pages_warehouse_management_warehouse_management_component__WEBPACK_IMPORTED_MODULE_4__["WarehouseManagementComponent"]
    },
    {
        path: 'WarehouseAnalytics',
        component: _pages_warehouse_analytics_warehouse_analytics_component__WEBPACK_IMPORTED_MODULE_3__["WarehouseAnalyticsComponent"]
    },
    {
        path: '',
        redirectTo: '',
        pathMatch: 'full'
    },
];
var ExpertiseRoutingModule = /** @class */ (function () {
    function ExpertiseRoutingModule() {
    }
    ExpertiseRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ExpertiseRoutingModule);
    return ExpertiseRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/expertise/expertise.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/modules/expertise/expertise.module.ts ***!
  \*******************************************************/
/*! exports provided: ExpertiseModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ExpertiseModule", function() { return ExpertiseModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _expertise_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./expertise-routing.module */ "./src/app/modules/expertise/expertise-routing.module.ts");
/* harmony import */ var _pages_warehouse_analytics_warehouse_analytics_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/warehouse-analytics/warehouse-analytics.component */ "./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.ts");
/* harmony import */ var _pages_warehouse_management_warehouse_management_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pages/warehouse-management/warehouse-management.component */ "./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.ts");






var ExpertiseModule = /** @class */ (function () {
    function ExpertiseModule() {
    }
    ExpertiseModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_pages_warehouse_analytics_warehouse_analytics_component__WEBPACK_IMPORTED_MODULE_4__["WarehouseAnalyticsComponent"], _pages_warehouse_management_warehouse_management_component__WEBPACK_IMPORTED_MODULE_5__["WarehouseManagementComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _expertise_routing_module__WEBPACK_IMPORTED_MODULE_3__["ExpertiseRoutingModule"]
            ]
        })
    ], ExpertiseModule);
    return ExpertiseModule;
}());



/***/ }),

/***/ "./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.css":
/*!***********************************************************************************************!*\
  !*** ./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.css ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".w3l-content-with-photo-23 .cwp23-content {\r\n  grid-template-columns: 1fr 1fr;\r\n  grid-column-gap: 3rem;\r\n}\r\n.w3l-features-6 .fea-gd-vv {\r\n  /* grid-template-columns: 1fr 1fr 1fr; */\r\n  grid-template-columns: none;\r\n  display: grid;\r\n  grid-gap: 20px;\r\n}\r\nli {\r\n  list-style-type: circle;\r\n  font-size: 16px;\r\n  line-height: 24px;\r\n  color: var(--text-color);\r\n}\r\n.w3l-features-6 .features {\r\n  padding: 0px 0;\r\n}\r\n.w3l-content-with-photo-23 #cwp23-block {\r\n  padding: 5rem 0 1rem;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9leHBlcnRpc2UvcGFnZXMvd2FyZWhvdXNlLWFuYWx5dGljcy93YXJlaG91c2UtYW5hbHl0aWNzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSw4QkFBOEI7RUFDOUIscUJBQXFCO0FBQ3ZCO0FBQ0E7RUFDRSx3Q0FBd0M7RUFDeEMsMkJBQTJCO0VBQzNCLGFBQWE7RUFDYixjQUFjO0FBQ2hCO0FBQ0E7RUFDRSx1QkFBdUI7RUFDdkIsZUFBZTtFQUNmLGlCQUFpQjtFQUNqQix3QkFBd0I7QUFDMUI7QUFDQTtFQUNFLGNBQWM7QUFDaEI7QUFDQTtFQUNFLG9CQUFvQjtBQUN0QiIsImZpbGUiOiJzcmMvYXBwL21vZHVsZXMvZXhwZXJ0aXNlL3BhZ2VzL3dhcmVob3VzZS1hbmFseXRpY3Mvd2FyZWhvdXNlLWFuYWx5dGljcy5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLnczbC1jb250ZW50LXdpdGgtcGhvdG8tMjMgLmN3cDIzLWNvbnRlbnQge1xyXG4gIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyIDFmcjtcclxuICBncmlkLWNvbHVtbi1nYXA6IDNyZW07XHJcbn1cclxuLnczbC1mZWF0dXJlcy02IC5mZWEtZ2QtdnYge1xyXG4gIC8qIGdyaWQtdGVtcGxhdGUtY29sdW1uczogMWZyIDFmciAxZnI7ICovXHJcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBub25lO1xyXG4gIGRpc3BsYXk6IGdyaWQ7XHJcbiAgZ3JpZC1nYXA6IDIwcHg7XHJcbn1cclxubGkge1xyXG4gIGxpc3Qtc3R5bGUtdHlwZTogY2lyY2xlO1xyXG4gIGZvbnQtc2l6ZTogMTZweDtcclxuICBsaW5lLWhlaWdodDogMjRweDtcclxuICBjb2xvcjogdmFyKC0tdGV4dC1jb2xvcik7XHJcbn1cclxuLnczbC1mZWF0dXJlcy02IC5mZWF0dXJlcyB7XHJcbiAgcGFkZGluZzogMHB4IDA7XHJcbn1cclxuLnczbC1jb250ZW50LXdpdGgtcGhvdG8tMjMgI2N3cDIzLWJsb2NrIHtcclxuICBwYWRkaW5nOiA1cmVtIDAgMXJlbTtcclxufVxyXG4iXX0= */"

/***/ }),

/***/ "./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.html":
/*!************************************************************************************************!*\
  !*** ./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.html ***!
  \************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3>Services</h3>\n        <li><a href=\"\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">Warehouse Analytics</li>\n      </ul>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-content-with-photo-23\">\n  <div id=\"cwp23-block\">\n    <div class=\"wrapper\">\n      <div class=\"section-title align-center text-center\">\n        <h3>Warehouse Analytics</h3>\n        <h4> Smart and effective solutions for businesses.</h4>\n        <p class=\"sub-paragraph\">n1re provides comprehensive solutions and services that meet and exceed the business\n          needs and goals of our clients.</p>\n      </div>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-features-6\">\n  <!-- /features -->\n  <div class=\"features\">\n    <div class=\"wrapper\">\n      <div class=\"fea-gd-vv\">\n        <div class=\"float-lt feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-file-text-o\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>SAP EWM analytics is provided through\n            </h5>\n            <ul>\n              <li>Warehouse cockpit</li>\n              <li>Warehouse Management monitor</li>\n              <li>Graphical Warehouse Layout</li>\n              <li>Business Intelligence-Reporting</li>\n            </ul>\n          </div>\n        </div>\n        <div class=\"float-mid feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-laptop\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>Warehouse cock pit</h5>\n            <p>\n              The Easy Graphics Framework (EGF) is a generic tool that you can use for the simple configuration of\n              cockpits for Extended Warehouse Management (EWM) applications You use these in addition to text-based\n              monitors and to display your data graphically using bars, stacks,time, speedometer and table.\n              Standard Cockpit contains the following EGF objects\n            </p>\n          </div>\n        </div>\n        <div class=\"float-rt feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-clone\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>Warehouse Management monitor </h5>\n            <p>\n              The warehouse management monitor is a central tool for keeping warehouse managers constantly up-to-date as\n              to the current situation in the warehouse, and to enable them to initiate appropriate responses in light\n              of this situation. The warehouse management monitor also contains alert monitoring capabilities, which\n              highlight to warehouse managers actual and potential problematic situations in the warehouse, and provide\n              exception handling tools.\n            </p>\n          </div>\n        </div>\n\n      </div>\n    </div>\n  </div>\n  <!-- //features -->\n</section>\n<br>"

/***/ }),

/***/ "./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.ts":
/*!**********************************************************************************************!*\
  !*** ./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.ts ***!
  \**********************************************************************************************/
/*! exports provided: WarehouseAnalyticsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WarehouseAnalyticsComponent", function() { return WarehouseAnalyticsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var WarehouseAnalyticsComponent = /** @class */ (function () {
    function WarehouseAnalyticsComponent() {
    }
    WarehouseAnalyticsComponent.prototype.ngOnInit = function () {
    };
    WarehouseAnalyticsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-warehouse-analytics',
            template: __webpack_require__(/*! ./warehouse-analytics.component.html */ "./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.html"),
            styles: [__webpack_require__(/*! ./warehouse-analytics.component.css */ "./src/app/modules/expertise/pages/warehouse-analytics/warehouse-analytics.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], WarehouseAnalyticsComponent);
    return WarehouseAnalyticsComponent;
}());



/***/ }),

/***/ "./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.css":
/*!*************************************************************************************************!*\
  !*** ./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.css ***!
  \*************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".w3l-content-with-photo-23 .cwp23-content {\r\n  grid-template-columns: 1fr 1fr;\r\n  grid-column-gap: 3rem;\r\n}\r\n.w3l-features-6 .fea-gd-vv {\r\n  /* grid-template-columns: 1fr 1fr 1fr; */\r\n  grid-template-columns: none;\r\n  display: grid;\r\n  grid-gap: 20px;\r\n}\r\nli {\r\n  list-style-type: circle;\r\n  font-size: 16px;\r\n  line-height: 24px;\r\n  color: var(--text-color);\r\n}\r\n.w3l-features-6 .features {\r\n  padding: 0px 0;\r\n}\r\n.w3l-content-with-photo-23 #cwp23-block {\r\n  padding: 5rem 0 1rem;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9leHBlcnRpc2UvcGFnZXMvd2FyZWhvdXNlLW1hbmFnZW1lbnQvd2FyZWhvdXNlLW1hbmFnZW1lbnQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLDhCQUE4QjtFQUM5QixxQkFBcUI7QUFDdkI7QUFDQTtFQUNFLHdDQUF3QztFQUN4QywyQkFBMkI7RUFDM0IsYUFBYTtFQUNiLGNBQWM7QUFDaEI7QUFDQTtFQUNFLHVCQUF1QjtFQUN2QixlQUFlO0VBQ2YsaUJBQWlCO0VBQ2pCLHdCQUF3QjtBQUMxQjtBQUNBO0VBQ0UsY0FBYztBQUNoQjtBQUNBO0VBQ0Usb0JBQW9CO0FBQ3RCIiwiZmlsZSI6InNyYy9hcHAvbW9kdWxlcy9leHBlcnRpc2UvcGFnZXMvd2FyZWhvdXNlLW1hbmFnZW1lbnQvd2FyZWhvdXNlLW1hbmFnZW1lbnQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi53M2wtY29udGVudC13aXRoLXBob3RvLTIzIC5jd3AyMy1jb250ZW50IHtcclxuICBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnI7XHJcbiAgZ3JpZC1jb2x1bW4tZ2FwOiAzcmVtO1xyXG59XHJcbi53M2wtZmVhdHVyZXMtNiAuZmVhLWdkLXZ2IHtcclxuICAvKiBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgMWZyOyAqL1xyXG4gIGdyaWQtdGVtcGxhdGUtY29sdW1uczogbm9uZTtcclxuICBkaXNwbGF5OiBncmlkO1xyXG4gIGdyaWQtZ2FwOiAyMHB4O1xyXG59XHJcbmxpIHtcclxuICBsaXN0LXN0eWxlLXR5cGU6IGNpcmNsZTtcclxuICBmb250LXNpemU6IDE2cHg7XHJcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XHJcbiAgY29sb3I6IHZhcigtLXRleHQtY29sb3IpO1xyXG59XHJcbi53M2wtZmVhdHVyZXMtNiAuZmVhdHVyZXMge1xyXG4gIHBhZGRpbmc6IDBweCAwO1xyXG59XHJcbi53M2wtY29udGVudC13aXRoLXBob3RvLTIzICNjd3AyMy1ibG9jayB7XHJcbiAgcGFkZGluZzogNXJlbSAwIDFyZW07XHJcbn1cclxuIl19 */"

/***/ }),

/***/ "./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.html":
/*!**************************************************************************************************!*\
  !*** ./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.html ***!
  \**************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3>Services</h3>\n        <li><a href=\"\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">Warehouse Management</li>\n      </ul>\n    </div>\n  </div>\n</section>\n\n<section class=\"w3l-content-with-photo-23\">\n  <div id=\"cwp23-block\">\n    <div class=\"wrapper\">\n      <div class=\"section-title align-center text-center\">\n        <h3>Warehouse Management</h3>\n        <h4> Smart and effective solutions for businesses.</h4>\n        <p class=\"sub-paragraph\">n1re provides comprehensive solutions and services that meet and exceed the business\n          needs and goals of our clients.</p>\n      </div>\n      <!-- <div class=\"d-grid cwp23-content\">\n              <div class=\"cwp23-img\">\n                <div class=\"cwp23-text-cols\">\n                  <div class=\"column ser-lft\">\n                      <h4>ERP Warehouse Management</h4>\n                      <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor </p>\n                  </div>                    \n              </div>\n              </div>\n              <div class=\"cwp23-text\">\n                  <div class=\"cwp23-text-cols\">\n                      <div class=\"column ser-lft\">\n                          <h4>WarehouseAnalytics</h4>\n                          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor </p>\n                      </div>                    \n                  </div>\n              </div>\n          </div>-->\n    </div>\n  </div>\n</section>\n\n<section class=\"w3l-features-6\">\n  <!-- /features -->\n  <div class=\"features\">\n    <div class=\"wrapper\">\n      <div class=\"fea-gd-vv\">\n        <div class=\"float-lt feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-file-text-o\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>Key Challenges to overcome & Need for Warehouse Management</h5>\n            <p>Successful companies depend on an optimized, flexible & agile supply chain to achieve superior customer\n              service levels there by improved customer satisfaction & customer retention rate while reducing their\n              operating costs. This places high demands on the warehouse processes and its integration with other\n              systems.</p>\n            <ul>\n              <li>Integrating new Customers, Distribution channels, Products, Services and Customer specific processes\n                globally in a rapid and efficient manner.</li>\n              <li>Organizing the warehouse in order to fulfill high volumes and as well complying with cost efficient\n                service levels-Warehouse efficiency.</li>\n              <li>Coordinating the flow of material and information for maximizing the visibility, inventory accuracy\n                and tighter control on the orders and warehouse load</li>\n              <li>Timely identification and resolution of critical situation and managing the situations both\n                proactively and by exception </li>\n              <li>Optimize the warehouse resources ( Assets, Labor, Space, Equipments)</li>\n              <li>Address the increased compliance and regulatory requirements.</li>\n\n            </ul>\n          </div>\n        </div>\n        <div class=\"float-mid feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-laptop\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>Extended Warehouse Management</h5>\n            <p>\n              Extended Warehouse Management (EWM) is the SAP’s best of breed solution to handle current & future\n              warehouse operational challenges and dynamic customer demands.</p>\n            <p>\n              SAP EWM is built on supply chain execution platform that provides integrated planning, orchestration,\n              execution and tracking of the physical movement of goods. SAP net weaver deployment option is also\n              available from EWM 9.1\n            </p>\n            <p>\n              EWM is designed for the kill with its robust & integrated processes that are evolved for more than two\n              decades since the R2 WM days. Extensive array of features, functionalities, analytics, monitoring\n              dashboards and tools provided in EWM addresses the ever-changing business requirements comprehensively.\n            </p>\n            <p>\n              It is important to note that SAP EWM is not replacement to ERP- WM and also important is ERP-WM is not\n              being developed any further.\n            </p>\n            <p>\n              SAP EWM is the strategic positioning and ongoing development platform.EWM in general was designed for high\n              performance, high volume warehouse operations and to support complex warehouse processes with in- depth\n              integration with other modules\n            </p>\n            <ul>\n              <li>Covers all types of warehouses – Distribution centre, Manufacturing warehouse, Yard warehouse, Spares\n                warehouse and Transit warehouse</li>\n              <li>Network focus as opposed to Enterprise focus.</li>\n              <li>Supports simple to complex warehouse processes. It can handle any degree of product / Layout\n                complexities, huge delivery volumes and in depth integration needs </li>\n              <li>Address industry specific requirements like Serial numbers, Catch weight, Merchandize flow through ,\n                Stock specific UOM’s ,Cross docking</li>\n              <li>Provide built in optimization, automation and Integration capabilities</li>\n            </ul>\n          </div>\n        </div>\n        <div class=\"float-rt feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-clone\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>Why SAP Warehouse Management </h5>\n            <ul>\n              <li>Best of Breed functionality + the advantage of lower TCO.</li>\n              <li>Vendor viability and long term commitment to SCM</li>\n              <li>Standard interfaces/integration to SAP ERP Vs Custom or complex interfaces to 3rd Party WMS</li>\n              <li>Ability to Adopt new technology &amp; Sense and respond nature to business pain points</li>\n              <li>Cost avoidance around legacy WMS solutions</li>\n            </ul>\n          </div>\n        </div>\n        <div class=\"float-lt feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-bullseye\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>SAP’s WMS offering </h5>\n            <ul>\n              <li>Lean WM</li>\n              <li>ERP-WM</li>\n              <li>Decentralized WM along with TRM</li>\n              <li>Extended WM(EWM)</li>\n            </ul>\n          </div>\n        </div>\n        <div class=\"float-mid feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-cube\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>ERP-WM </h5>\n            <p>ERP-WM is in place since 1993 built initially for small and medium warehouses and having basic\n              integration with production, quality and Logistics Information systems.</p>\n            <p>\n              Brief history of major releases from 1995 till 2004\n            </p>\n            <ul>\n              <li>R/3 Release 4.0: Wave picking, two step picking, warehouse monitor and HR integration.</li>\n              <li>R/3 Release 4.5 : SAP has released Decentralized WM where WM can be installed in separate box to\n                ensure 24*7 availability and flexible upgrade</li>\n              <li>R/3 Release 4.6: SAP has introduced the native Radio frequency and Handling unit Management.</li>\n              <li>R/3 Release 4.7: The last major developments were added in 4.7 Extension set 1 where in TRM was\n                introduced and in Extension set 2 cross docking, yard management and VAS. </li>\n            </ul>\n          </div>\n        </div>\n        <div class=\"float-mid feature-gd\">\n          <div class=\"icon\"> <span class=\"fa fa-cube\" aria-hidden=\"true\"></span></div>\n          <div class=\"icon-info\">\n            <h5>SAP EWM key capabilities </h5>\n            <p>\n              EWM has continued to evolve more rapidly in the last 10 years, lots of features & functionalities were\n              released starting EWM 5.0 all the way to the current EWM 9.4 with each release offering compelling\n              functionalities.</p>\n            <ul>\n              <li>Flexible modeling of warehouse( Using Org elements) and processes ( Processes mapped using POSC and\n                LOSC)</li>\n              <li>Efficient and robust put away, picking strategies and Slotting &amp; Rearrangement.</li>\n              <li>Strong Integration with Other SAP solutions viz Transportation, Yard Management, Quality Management,\n                Production, Advanced Returns Management, CRM, SCM planning and Global Trade Services GTS.</li>\n              <li>Integration with RF and RFID </li>\n              <li>Integration with Material Flow Systems MFS ( PLC systems- ASRS, Conveyor systems)</li>\n              <li>Increased Labor productivity through Labor Management</li>\n              <li>Better resource utilization through Resource Management- (Human resources &amp; Equipments like\n                Forklifts, conveyors, cranes, TSP , reach trucks etc.,)</li>\n              <li>Supports all value added services-( Eg: Kitting, Oiling, Shrink wrapping, Price marking , Labeling,\n                Customer specific packaging )</li>\n              <li>Stock and process transparency</li>\n              <li>Manage by exceptions</li>\n              <li>Reporting and Analytics</li>\n            </ul>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n  <!-- //features -->\n</section>\n\n<br>"

/***/ }),

/***/ "./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.ts":
/*!************************************************************************************************!*\
  !*** ./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.ts ***!
  \************************************************************************************************/
/*! exports provided: WarehouseManagementComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WarehouseManagementComponent", function() { return WarehouseManagementComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");


var WarehouseManagementComponent = /** @class */ (function () {
    function WarehouseManagementComponent() {
    }
    WarehouseManagementComponent.prototype.ngOnInit = function () {
    };
    WarehouseManagementComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-warehouse-management',
            template: __webpack_require__(/*! ./warehouse-management.component.html */ "./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.html"),
            styles: [__webpack_require__(/*! ./warehouse-management.component.css */ "./src/app/modules/expertise/pages/warehouse-management/warehouse-management.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [])
    ], WarehouseManagementComponent);
    return WarehouseManagementComponent;
}());



/***/ })

}]);
//# sourceMappingURL=src-app-modules-expertise-expertise-module.js.map