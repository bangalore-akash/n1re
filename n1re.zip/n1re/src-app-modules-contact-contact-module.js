(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-modules-contact-contact-module"],{

/***/ "./src/app/modules/contact/contact-routing.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/modules/contact/contact-routing.module.ts ***!
  \***********************************************************/
/*! exports provided: ContactRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactRoutingModule", function() { return ContactRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _pages_contact_contact_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/contact/contact.component */ "./src/app/modules/contact/pages/contact/contact.component.ts");




var routes = [
    {
        path: '',
        component: _pages_contact_contact_component__WEBPACK_IMPORTED_MODULE_3__["ContactComponent"]
    }
];
var ContactRoutingModule = /** @class */ (function () {
    function ContactRoutingModule() {
    }
    ContactRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], ContactRoutingModule);
    return ContactRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/contact/contact.module.ts":
/*!***************************************************!*\
  !*** ./src/app/modules/contact/contact.module.ts ***!
  \***************************************************/
/*! exports provided: ContactModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactModule", function() { return ContactModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _contact_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./contact-routing.module */ "./src/app/modules/contact/contact-routing.module.ts");
/* harmony import */ var _pages_contact_contact_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/contact/contact.component */ "./src/app/modules/contact/pages/contact/contact.component.ts");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/shared.module */ "./src/app/shared/shared.module.ts");






var ContactModule = /** @class */ (function () {
    function ContactModule() {
    }
    ContactModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_pages_contact_contact_component__WEBPACK_IMPORTED_MODULE_4__["ContactComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _contact_routing_module__WEBPACK_IMPORTED_MODULE_3__["ContactRoutingModule"],
                src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"]
            ]
        })
    ], ContactModule);
    return ContactModule;
}());



/***/ }),

/***/ "./src/app/modules/contact/pages/contact/contact.component.css":
/*!*********************************************************************!*\
  !*** ./src/app/modules/contact/pages/contact/contact.component.css ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".contact_social a {\r\n    margin-right: 10px;\r\n    color: #777;\r\n    background: #252525;\r\n    width: 35px;\r\n    height: 35px;\r\n    line-height: 35px;\r\n    display: inline-block;\r\n    text-align: center;\r\n    font-size: 14px;\r\n    border-radius: 50%;\r\n    -webkit-transition: 0.3s;\r\n    transition: 0.3s;\r\n    padding: 0px 0px 1px 11px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9jb250YWN0L3BhZ2VzL2NvbnRhY3QvY29udGFjdC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksa0JBQWtCO0lBQ2xCLFdBQVc7SUFDWCxtQkFBbUI7SUFDbkIsV0FBVztJQUNYLFlBQVk7SUFDWixpQkFBaUI7SUFDakIscUJBQXFCO0lBQ3JCLGtCQUFrQjtJQUNsQixlQUFlO0lBQ2Ysa0JBQWtCO0lBQ2xCLHdCQUFnQjtJQUFoQixnQkFBZ0I7SUFDaEIseUJBQXlCO0FBQzdCIiwiZmlsZSI6InNyYy9hcHAvbW9kdWxlcy9jb250YWN0L3BhZ2VzL2NvbnRhY3QvY29udGFjdC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNvbnRhY3Rfc29jaWFsIGEge1xyXG4gICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgY29sb3I6ICM3Nzc7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMjUyNTI1O1xyXG4gICAgd2lkdGg6IDM1cHg7XHJcbiAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICBsaW5lLWhlaWdodDogMzVweDtcclxuICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIHRyYW5zaXRpb246IDAuM3M7XHJcbiAgICBwYWRkaW5nOiAwcHggMHB4IDFweCAxMXB4O1xyXG59Il19 */"

/***/ }),

/***/ "./src/app/modules/contact/pages/contact/contact.component.html":
/*!**********************************************************************!*\
  !*** ./src/app/modules/contact/pages/contact/contact.component.html ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3 style=\"color: #fff;\">Contact</h3>\n        <li><a (click)=\"navigate()\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">Contact Us\n        </li>\n      </ul>\n    </div>\n  </div>\n</section>\n<!-- contacts -->\n<section class=\"w3l-contacts-9-main\">\n  <div class=\"contacts-9\">\n    <div class=\"wrapper\">\n      <div class=\"top-map\">\n\n        <div class=\"map-content-9\">\n          <form>\n            <div class=\"form-top1\">\n              <h3>Contact Us</h3>\n              <div class=\"form-top\">\n\n                <div class=\"form-top-left\">\n\n                  <input type=\"text\" name=\"w3lName\"  placeholder=\"Name\" required=\"\">\n                  <input type=\"email\" name=\"w3lSender\"  placeholder=\"Email\" required=\"\">\n                  <input type=\"text\" name=\"w3lName\"  placeholder=\"Mobile\" required=\"\">\n                </div>\n                <div class=\"form-top-righ\">\n                  <textarea name=\"w3lMessage\" id=\"w3lMessage\" placeholder=\"Message\" required=\"\"></textarea>\n                  <button type=\"submit\">Send</button>\n                </div>\n              </div>\n            </div>\n          </form>\n        </div>\n        <div class=\"cont-details\">\n          <div class=\"cont-top\">\n            <h6><span class=\"fa fa-map-marker\"></span> ADDRESS</h6>\n            <p>n1re ,\n              Raheja Towers, 10th Floor, West Wing,\n              M G Road Bangalore,\n              BENGALURU - 560001, <br> Karnataka,<br> India</p>\n          </div>\n          <div class=\"cont-top\">\n            <h6><span class=\"fa fa-phone\"></span> CONTACT</h6>\n            <!--<p>BENGALURU - 560037, Karnataka, India</p>-->\n            <p><a href=\"tel:+91 9439740000\">+91 9439740000</a></p>\n            <p><a href=\"mailto:info@n1re.com\">info@n1re.com</a></p>\n            <p><a href=\"mailto:contact@n1re.com\">contact@n1re.com</a></p>\n\n          </div>\n          <div class=\"cont-top\">\n            <h6><span class=\"fa fa-map-marker\"></span> SOCIAL MEDIA </h6>\n            <br>\n            <div class=\"contact_social\">\n              <a href=\"#facebook\" class=\"facebook\"><span class=\"fa fa-facebook\"></span></a>\n              <a href=\"#twitter\" class=\"twitter\"><span class=\"fa fa-twitter\"></span></a>\n              <a href=\"#instagram\" class=\"instagram\"><span class=\"fa fa-instagram\"></span></a>\n              <a href=\"#google-plus\" class=\"google-plus\"><span class=\"fa fa-google-plus\"></span></a>\n              <a href=\"#linkedin\" class=\"linkedin\"><span class=\"fa fa-linkedin\"></span></a>\n            </div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</section>"

/***/ }),

/***/ "./src/app/modules/contact/pages/contact/contact.component.ts":
/*!********************************************************************!*\
  !*** ./src/app/modules/contact/pages/contact/contact.component.ts ***!
  \********************************************************************/
/*! exports provided: ContactComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactComponent", function() { return ContactComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var ContactComponent = /** @class */ (function () {
    function ContactComponent(router) {
        this.router = router;
    }
    ContactComponent.prototype.ngOnInit = function () {
    };
    ContactComponent.prototype.navigate = function () {
        this.router.navigateByUrl('home');
    };
    ContactComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-contact',
            template: __webpack_require__(/*! ./contact.component.html */ "./src/app/modules/contact/pages/contact/contact.component.html"),
            styles: [__webpack_require__(/*! ./contact.component.css */ "./src/app/modules/contact/pages/contact/contact.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], ContactComponent);
    return ContactComponent;
}());



/***/ })

}]);
//# sourceMappingURL=src-app-modules-contact-contact-module.js.map