(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-modules-about-about-module"],{

/***/ "./src/app/modules/about/about-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/modules/about/about-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: AboutRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutRoutingModule", function() { return AboutRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _pages_about_about_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/about/about.component */ "./src/app/modules/about/pages/about/about.component.ts");
/* harmony import */ var _pages_why_us_why_us_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/why-us/why-us.component */ "./src/app/modules/about/pages/why-us/why-us.component.ts");





var routes = [
    {
        path: '',
        component: _pages_about_about_component__WEBPACK_IMPORTED_MODULE_3__["AboutComponent"],
    },
    {
        path: 'whyUs',
        component: _pages_why_us_why_us_component__WEBPACK_IMPORTED_MODULE_4__["WhyUsComponent"],
    },
];
var AboutRoutingModule = /** @class */ (function () {
    function AboutRoutingModule() {
    }
    AboutRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [],
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        })
    ], AboutRoutingModule);
    return AboutRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/about/about.module.ts":
/*!***********************************************!*\
  !*** ./src/app/modules/about/about.module.ts ***!
  \***********************************************/
/*! exports provided: AboutModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutModule", function() { return AboutModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _about_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./about-routing.module */ "./src/app/modules/about/about-routing.module.ts");
/* harmony import */ var _pages_about_about_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./pages/about/about.component */ "./src/app/modules/about/pages/about/about.component.ts");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var _pages_why_us_why_us_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./pages/why-us/why-us.component */ "./src/app/modules/about/pages/why-us/why-us.component.ts");







var AboutModule = /** @class */ (function () {
    function AboutModule() {
    }
    AboutModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_pages_about_about_component__WEBPACK_IMPORTED_MODULE_4__["AboutComponent"], _pages_why_us_why_us_component__WEBPACK_IMPORTED_MODULE_6__["WhyUsComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _about_routing_module__WEBPACK_IMPORTED_MODULE_3__["AboutRoutingModule"],
                src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"]
            ]
        })
    ], AboutModule);
    return AboutModule;
}());



/***/ }),

/***/ "./src/app/modules/about/pages/about/about.component.css":
/*!***************************************************************!*\
  !*** ./src/app/modules/about/pages/about/about.component.css ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".w3l-blog-main-61 .box13 img {\r\n    /* display: block; */\r\n    margin: auto;\r\n    /* width: 76%; */\r\n    height: 400px;\r\n}\r\n.w3l-blog-main-61 .blg-tp {\r\n  grid-template-columns: 1fr 1fr;\r\n  display: grid;\r\n  -o-box-shadow: none;\r\n  box-shadow: none;\r\n  /* margin-bottom: 24px; */\r\n}\r\n.w3l-blog-main-61 .grids-layout {\r\n    background: #fafafa;\r\n    padding: 40px 0;\r\n}\r\n\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9hYm91dC9wYWdlcy9hYm91dC9hYm91dC5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0lBQ0ksb0JBQW9CO0lBQ3BCLFlBQVk7SUFDWixnQkFBZ0I7SUFDaEIsYUFBYTtBQUNqQjtBQUNBO0VBQ0UsOEJBQThCO0VBQzlCLGFBQWE7RUFDYixtQkFBbUI7RUFDbkIsZ0JBQWdCO0VBQ2hCLHlCQUF5QjtBQUMzQjtBQUNBO0lBQ0ksbUJBQW1CO0lBQ25CLGVBQWU7QUFDbkIiLCJmaWxlIjoic3JjL2FwcC9tb2R1bGVzL2Fib3V0L3BhZ2VzL2Fib3V0L2Fib3V0LmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudzNsLWJsb2ctbWFpbi02MSAuYm94MTMgaW1nIHtcclxuICAgIC8qIGRpc3BsYXk6IGJsb2NrOyAqL1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgLyogd2lkdGg6IDc2JTsgKi9cclxuICAgIGhlaWdodDogNDAwcHg7XHJcbn1cclxuLnczbC1ibG9nLW1haW4tNjEgLmJsZy10cCB7XHJcbiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiAxZnIgMWZyO1xyXG4gIGRpc3BsYXk6IGdyaWQ7XHJcbiAgLW8tYm94LXNoYWRvdzogbm9uZTtcclxuICBib3gtc2hhZG93OiBub25lO1xyXG4gIC8qIG1hcmdpbi1ib3R0b206IDI0cHg7ICovXHJcbn1cclxuLnczbC1ibG9nLW1haW4tNjEgLmdyaWRzLWxheW91dCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjZmFmYWZhO1xyXG4gICAgcGFkZGluZzogNDBweCAwO1xyXG59XHJcbiJdfQ== */"

/***/ }),

/***/ "./src/app/modules/about/pages/about/about.component.html":
/*!****************************************************************!*\
  !*** ./src/app/modules/about/pages/about/about.component.html ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n  <div class=\"about-inner\">\n    <div class=\"wrapper\">\n      <ul class=\"breadcrumbs-custom-path\">\n        <h3 style=\"color: #fff;\">About Us</h3>\n        <li><a (click)=\"navigate()\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n        <li class=\"active\">About Us</li>\n      </ul>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-blog-main-61\">\n  <!-- /grids -->\n  <div class=\"grids-layout\">\n    <div class=\"wrapper\">\n      <div class=\"gallery-25-content\">\n        <div class=\"d-grid grid-columns\">\n          <div class=\"blg-tp\">\n            <div class=\"column two two-blog\">\n              <div class=\"box13\">\n                <h3><a style=\"text-decoration: none;\">Everyone Deserves The Opportunity Of a Home</a>\n                </h3>\n                <p>n1re is an online real estate advisor that functions on the fundamentals of trust,\n                  transparency and expertise. As a digital marketplace with an exhaustive range of property listings, we\n                  know it is easy to get lost. At n1re, we guide home buyers right from the start of their home\n                  search to the very end. Browse through more than 139,000 verified real estate properties with accurate\n                  lowdown on amenities, neighborhoods and cities, and genuine pictures. Shortlist your favorite homes\n                  and allow us to arrange site visits. Our work does not end here. We assist you with home loans and\n                  property registrations. Buying a home is an important investment – turn it into your safest, best deal\n                  at n1re.</p>\n\n                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Obcaecati veniam\n                  suscipit,\n                  dolorem cupiditate esse illum inventore laboriosam maiores non, repudiandae\n                  cumque?</p>\n              </div>\n            </div>\n            <div class=\"column one-blog\">\n              <div class=\"box13\">\n                <a href=\"blog-single.html\"><img class=\"side-img\" src=\"assets/images/b2.jpg\" class=\"img-responsive\"\n                    alt=\"\" /></a>\n              </div>\n            </div>\n\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n<section class=\"w3l-timeline-block\">\n  <ul class=\"timeline\">\n    <li class=\"timeline-event\">\n      <label class=\"timeline-event-icon\"></label>\n      <div class=\"timeline-event-copy\">\n        <p class=\"timeline-event-thumbnail\">ABOUT US</p>\n        <!--<h3>Sed ut perspiciatis unde</h3>\n      <h4>Developer</h4>-->\n        <p>N1re is a comprehensive platform for real estate data and analytics. It is designed to provide\n          our stakeholders with timely, accurate, insightful intelligence on residential real estate across Tier - I &\n          II cities. N1re combines the award-winning N1re sales expertise with understanding of local markets.\n        </p>\n      </div>\n    </li>\n    <li class=\"timeline-event\">\n      <label class=\"timeline-event-icon\"></label>\n      <div class=\"timeline-event-copy\">\n        <p>The wide spectrum of outputs is collated by a dedicated team of over 150 researchers across 42+ cities in\n          India. With real time tracking of 50+ parameters with macro and micro detailing, we cover the residential\n          sector pan India, to empower home buyers, real estate developers and financial institutions with indepth\n          customised data and analysis, for an ever informed decision making.</p>\n      </div>\n    </li>\n    <li class=\"timeline-event\">\n      <label class=\"timeline-event-icon\"></label>\n      <div class=\"timeline-event-copy\">\n        <p>N1re is a unique product wherein we are able to leverage international expertise on real estate data\n          operations and analytics through the backing of News Corp along with Saif and Accel Partners, our strategic\n          partners in journey to excellence. A cloud based solution, N1re can be accessed from anywhere and at\n          anytime, at just a click of a button.</p>\n      </div>\n    </li>\n  </ul>\n</section>"

/***/ }),

/***/ "./src/app/modules/about/pages/about/about.component.ts":
/*!**************************************************************!*\
  !*** ./src/app/modules/about/pages/about/about.component.ts ***!
  \**************************************************************/
/*! exports provided: AboutComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AboutComponent", function() { return AboutComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var AboutComponent = /** @class */ (function () {
    function AboutComponent(router) {
        this.router = router;
    }
    AboutComponent.prototype.ngOnInit = function () {
    };
    AboutComponent.prototype.navigate = function () {
        this.router.navigateByUrl('home');
    };
    AboutComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-about',
            template: __webpack_require__(/*! ./about.component.html */ "./src/app/modules/about/pages/about/about.component.html"),
            styles: [__webpack_require__(/*! ./about.component.css */ "./src/app/modules/about/pages/about/about.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], AboutComponent);
    return AboutComponent;
}());



/***/ }),

/***/ "./src/app/modules/about/pages/why-us/why-us.component.css":
/*!*****************************************************************!*\
  !*** ./src/app/modules/about/pages/why-us/why-us.component.css ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".w3l-features-6 .fea-gd-vv {\r\n    /* grid-template-columns: 1fr 1fr 1fr; */\r\n    grid-template-columns: none;\r\n    display: grid;\r\n    grid-gap: 20px;\r\n}\r\n\r\np{\r\n    text-align: justify;\r\n}\r\n\r\n.feature-grids p {\r\n    font-size: 16px;\r\n    line-height: 28px;\r\n    color: var(--text-color);\r\n}\r\n\r\n.section-title h4 {\r\n    /* font-size: 35px; */\r\n    /* line-height: 40px; */\r\n    /* color: var(--title-color); */\r\n    margin-bottom: 20px;\r\n    font-size: 35px;\r\n    line-height: 40px;\r\n    color: var(--title-color);\r\n    /* margin-top: 20px; */\r\n    font-family: \"Playfair Display\", sans-serif;\r\n    letter-spacing: 2px;\r\n    word-spacing: 2px;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9hYm91dC9wYWdlcy93aHktdXMvd2h5LXVzLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7SUFDSSx3Q0FBd0M7SUFDeEMsMkJBQTJCO0lBQzNCLGFBQWE7SUFDYixjQUFjO0FBQ2xCOztBQUVBO0lBQ0ksbUJBQW1CO0FBQ3ZCOztBQUNBO0lBQ0ksZUFBZTtJQUNmLGlCQUFpQjtJQUNqQix3QkFBd0I7QUFDNUI7O0FBRUE7SUFDSSxxQkFBcUI7SUFDckIsdUJBQXVCO0lBQ3ZCLCtCQUErQjtJQUMvQixtQkFBbUI7SUFDbkIsZUFBZTtJQUNmLGlCQUFpQjtJQUNqQix5QkFBeUI7SUFDekIsc0JBQXNCO0lBQ3RCLDJDQUEyQztJQUMzQyxtQkFBbUI7SUFDbkIsaUJBQWlCO0FBQ3JCIiwiZmlsZSI6InNyYy9hcHAvbW9kdWxlcy9hYm91dC9wYWdlcy93aHktdXMvd2h5LXVzLmNvbXBvbmVudC5jc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudzNsLWZlYXR1cmVzLTYgLmZlYS1nZC12diB7XHJcbiAgICAvKiBncmlkLXRlbXBsYXRlLWNvbHVtbnM6IDFmciAxZnIgMWZyOyAqL1xyXG4gICAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOiBub25lO1xyXG4gICAgZGlzcGxheTogZ3JpZDtcclxuICAgIGdyaWQtZ2FwOiAyMHB4O1xyXG59XHJcblxyXG5we1xyXG4gICAgdGV4dC1hbGlnbjoganVzdGlmeTtcclxufVxyXG4uZmVhdHVyZS1ncmlkcyBwIHtcclxuICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyOHB4O1xyXG4gICAgY29sb3I6IHZhcigtLXRleHQtY29sb3IpO1xyXG59XHJcblxyXG4uc2VjdGlvbi10aXRsZSBoNCB7XHJcbiAgICAvKiBmb250LXNpemU6IDM1cHg7ICovXHJcbiAgICAvKiBsaW5lLWhlaWdodDogNDBweDsgKi9cclxuICAgIC8qIGNvbG9yOiB2YXIoLS10aXRsZS1jb2xvcik7ICovXHJcbiAgICBtYXJnaW4tYm90dG9tOiAyMHB4O1xyXG4gICAgZm9udC1zaXplOiAzNXB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDQwcHg7XHJcbiAgICBjb2xvcjogdmFyKC0tdGl0bGUtY29sb3IpO1xyXG4gICAgLyogbWFyZ2luLXRvcDogMjBweDsgKi9cclxuICAgIGZvbnQtZmFtaWx5OiBcIlBsYXlmYWlyIERpc3BsYXlcIiwgc2Fucy1zZXJpZjtcclxuICAgIGxldHRlci1zcGFjaW5nOiAycHg7XHJcbiAgICB3b3JkLXNwYWNpbmc6IDJweDtcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/modules/about/pages/why-us/why-us.component.html":
/*!******************************************************************!*\
  !*** ./src/app/modules/about/pages/why-us/why-us.component.html ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"w3l-inner-banner-main\">\n   <div class=\"about-inner\">\n      <div class=\"wrapper\">\n         <ul class=\"breadcrumbs-custom-path\">\n            <h3 style=\"color: #fff;\">Why Us</h3>\n            <li><a (click)=\"navigate()\">Home <span class=\"fa fa-angle-right\" aria-hidden=\"true\"></span></a></li>\n            <li class=\"active\">Why Us</li>\n         </ul>\n      </div>\n   </div>\n</section>\n<section class=\"about py-lg-5 py-md-5 py-5\">\n   <div class=\"container\">\n      <!---728x90--->\n\n      <div class=\"inner-sec-w3pvt py-lg-5 py-3\">\n         <h3 class=\"tittle text-center mb-lg-5 mb-3 px-lg-5\"><span class=\"sub-tittle\"></span>Why Choose Us</h3>\n         <!---728x90--->\n         <div class=\"feature-grids row mt-3 mb-lg-5 mb-3 text-center\">\n            <div class=\"col-lg-6\" data-aos=\"fade-up\">\n               <div class=\"bottom-gd px-3\">\n                  <span class=\"fa fa-building-o\" aria-hidden=\"true\"></span>\n                  <h3 class=\"my-4\">Our Philosophy</h3>\n                  <p>It's quite simple. Tell the world about the property with as much transparency as possible. Buyers\n                     want to know as much as they can about the property before they visit so by giving out all the\n                     details more genuine and qualified buyers inspect a home. More and more buyers are using the web to\n                     do their homework when they are looking to buy a property.</p>\n               </div>\n            </div>\n            <div class=\"col-lg-6\" data-aos=\"fade-up\">\n               <div class=\"bottom-gd2-active px-3\">\n                  <span class=\"fa fa-cogs\" aria-hidden=\"true\"></span>\n                  <h3 class=\"my-4\"> 100% Workmanship Guarantee</h3>\n                  <p>Our internal processes ensures regular quality checks are performed at each stage of the project so\n                     you are assured your project is being performed to our own high quality standards and also to\n                     regulatory standards. Having these processes in place means we can offer you our “Platinum\n                     Guarantee”. In the unlikely event any faults are found in workmanship, they will be taken care of.\n                  </p>\n               </div>\n            </div>\n         </div>\n         <div class=\"feature-grids row mt-3 mb-lg-5 mb-3 text-center\">\n            <div class=\"col-lg-6\" data-aos=\"fade-up\">\n               <div class=\"bottom-gd px-3\">\n                  <span class=\"fa fa-building-o\" aria-hidden=\"true\"></span>\n                  <h3 class=\"my-4\">Satisfied Customers</h3>\n                  <p>We are extremely proud to have been involved in many building projects, results of which can be\n                     seen in our testimonials from satisfied customers. We believe you are only as good as your last\n                     job. Our work history shows that 90% of our work comes from referrals of satisfied customers. This\n                     is the best compliment Platinum could receive and the results can be easily verified in our\n                     testimonials.</p>\n               </div>\n            </div>\n            <div class=\"col-lg-6\" data-aos=\"fade-up\">\n               <div class=\"bottom-gd2-active px-3\">\n                  <span class=\"fa fa-cogs\" aria-hidden=\"true\"></span>\n                  <h3 class=\"my-4\"> A great return on your investment</h3>\n                  <p>It is a known fact that real estate has proved over the years to be a solid investment. That\n                     coupled with our time-tested designs, craftsmanship, quality products and upgraded amenities makes\n                     this a no-brainer. All our completed projects have proved to be a great investment in terms of\n                     returns & our ongoing and upcoming projects are no different.</p>\n               </div>\n            </div>\n         </div>\n         <div class=\"feature-grids row mt-3 mb-lg-5 mb-3 text-center\">\n            <div class=\"col-lg-6\" data-aos=\"fade-up\">\n               <div class=\"bottom-gd px-3\">\n                  <span class=\"fa fa-building-o\" aria-hidden=\"true\"></span>\n                  <h3 class=\"my-4\">On Time. Within Budget. Guaranteed.</h3>\n                  <p>Yes, you read that right. Our promise is that we will complete every project on time and within\n                     budget. This is backed by our guarantee. Not only do we apply our attention to detail to our\n                     building work, but to all project management as well. We are an enthusiastic company with friendly\n                     staff focused on delivering what you, the customer wants and pride ourselves in providing you the\n                     best quality construction service.</p>\n               </div>\n            </div>\n            <div class=\"col-lg-6\" data-aos=\"fade-up\">\n               <div class=\"bottom-gd2-active px-3\">\n                  <span class=\"fa fa-cogs\" aria-hidden=\"true\"></span>\n                  <h3 class=\"my-4\">Administrative Support</h3>\n                  <p>At Platinum, we employ an administrative team to provide full backup and support to our sales\n                     department. With the help of state of the art database systems and quality procedures, they ensure\n                     that all aspects of your property requirement are handled quickly and efficiently. You will always\n                     be kept informed, and there is never a chance of being “forgotten”, even after you move on!</p>\n               </div>\n            </div>\n         </div>\n      </div>\n   </div>\n</section>\n<section class=\"w3l-forms-9\">\n   <div class=\"main-w3\">\n      <div class=\"wrapper\">\n         <div class=\"grids-forms\">\n            <span class=\"fa fa-question\" aria-hidden=\"true\"></span>\n            <div class=\"main-midd\">\n               <h4 class=\"title-head\">Have Questions? </h4>\n               <p>Contact Our Manager For Details</p>\n            </div>\n            <div class=\"main-midd-2\">\n               <form action=\"#\" method=\"post\" class=\"rightside-form\">\n                  <input type=\"email\" style=\"visibility: hidden;\" name=\"email\" placeholder=\"Your Email..\" required>\n                  <button type=\"submit\" class=\"btn\">+91-9731313194</button>\n               </form>\n            </div>\n         </div>\n      </div>\n   </div>\n</section>"

/***/ }),

/***/ "./src/app/modules/about/pages/why-us/why-us.component.ts":
/*!****************************************************************!*\
  !*** ./src/app/modules/about/pages/why-us/why-us.component.ts ***!
  \****************************************************************/
/*! exports provided: WhyUsComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WhyUsComponent", function() { return WhyUsComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var WhyUsComponent = /** @class */ (function () {
    function WhyUsComponent(router) {
        this.router = router;
    }
    WhyUsComponent.prototype.ngOnInit = function () {
    };
    WhyUsComponent.prototype.navigate = function () {
        this.router.navigateByUrl('home');
    };
    WhyUsComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-why-us',
            template: __webpack_require__(/*! ./why-us.component.html */ "./src/app/modules/about/pages/why-us/why-us.component.html"),
            styles: [__webpack_require__(/*! ./why-us.component.css */ "./src/app/modules/about/pages/why-us/why-us.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], WhyUsComponent);
    return WhyUsComponent;
}());



/***/ })

}]);
//# sourceMappingURL=src-app-modules-about-about-module.js.map