(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["src-app-modules-home-home-module"],{

/***/ "./src/app/modules/home/home-routing/home-routing.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/modules/home/home-routing/home-routing.module.ts ***!
  \******************************************************************/
/*! exports provided: HomeRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeRoutingModule", function() { return HomeRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../pages/home/home.component */ "./src/app/modules/home/pages/home/home.component.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");





var routes = [
    {
        path: '',
        component: _pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__["HomeComponent"],
    }
];
var HomeRoutingModule = /** @class */ (function () {
    function HomeRoutingModule() {
    }
    HomeRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ]
        })
    ], HomeRoutingModule);
    return HomeRoutingModule;
}());



/***/ }),

/***/ "./src/app/modules/home/home.module.ts":
/*!*********************************************!*\
  !*** ./src/app/modules/home/home.module.ts ***!
  \*********************************************/
/*! exports provided: HomeModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeModule", function() { return HomeModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages/home/home.component */ "./src/app/modules/home/pages/home/home.component.ts");
/* harmony import */ var _home_routing_home_routing_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./home-routing/home-routing.module */ "./src/app/modules/home/home-routing/home-routing.module.ts");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/shared.module */ "./src/app/shared/shared.module.ts");
/* harmony import */ var ngx_owl_carousel_o__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ngx-owl-carousel-o */ "./node_modules/ngx-owl-carousel-o/fesm5/ngx-owl-carousel-o.js");







var HomeModule = /** @class */ (function () {
    function HomeModule() {
    }
    HomeModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [_pages_home_home_component__WEBPACK_IMPORTED_MODULE_3__["HomeComponent"]],
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _home_routing_home_routing_module__WEBPACK_IMPORTED_MODULE_4__["HomeRoutingModule"],
                src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_5__["SharedModule"],
                ngx_owl_carousel_o__WEBPACK_IMPORTED_MODULE_6__["CarouselModule"]
            ]
        })
    ], HomeModule);
    return HomeModule;
}());



/***/ }),

/***/ "./src/app/modules/home/pages/home/home.component.css":
/*!************************************************************!*\
  !*** ./src/app/modules/home/pages/home/home.component.css ***!
  \************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\r\n\r\n/* new  CSSS */\r\n.testimonials_grid_w3ls {\r\n  width: 100%;\r\n  margin: 0 auto;\r\n}\r\n.p-md-5 {\r\n  padding: 1rem !important;\r\n}\r\n.section-gap {\r\n  padding: 31px 0;\r\n}\r\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbW9kdWxlcy9ob21lL3BhZ2VzL2hvbWUvaG9tZS5jb21wb25lbnQuY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsY0FBYztBQUNkO0VBQ0UsV0FBVztFQUNYLGNBQWM7QUFDaEI7QUFDQTtFQUNFLHdCQUF3QjtBQUMxQjtBQUNBO0VBQ0UsZUFBZTtBQUNqQiIsImZpbGUiOiJzcmMvYXBwL21vZHVsZXMvaG9tZS9wYWdlcy9ob21lL2hvbWUuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIlxyXG5cclxuLyogbmV3ICBDU1NTICovXHJcbi50ZXN0aW1vbmlhbHNfZ3JpZF93M2xzIHtcclxuICB3aWR0aDogMTAwJTtcclxuICBtYXJnaW46IDAgYXV0bztcclxufVxyXG4ucC1tZC01IHtcclxuICBwYWRkaW5nOiAxcmVtICFpbXBvcnRhbnQ7XHJcbn1cclxuLnNlY3Rpb24tZ2FwIHtcclxuICBwYWRkaW5nOiAzMXB4IDA7XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/modules/home/pages/home/home.component.html":
/*!*************************************************************!*\
  !*** ./src/app/modules/home/pages/home/home.component.html ***!
  \*************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<section class=\"banner main-content\">\n  <div class=\"container\">\n    <div class=\"row banner-grids\">\n      <div class=\"col-lg-6 banner-info-w3ls\">\n        <h2>A Vision For Your Life\n        </h2>\n        <h3 class=\"mb-3\">Build Your Real & Dream Home ,At Real Time</h3>\n        <p class=\"mb-4\"> The right agents, with the right experience at the right time working for you. </p>\n        <a (click)=\"readMore()\" class=\"btn\">Read More</a>\n      </div>\n      <div class=\"col-lg-6 banner-image\">\n        <div class=\"img-effect\">\n          <img src=\"assets/images/img.jpg\" alt=\"\" class=\"img-fluid image1\">\n\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n\n<section class=\"about py-lg-5 py-md-5 py-5\">\n  <div class=\"container\">\n    <!---728x90--->\n\n    <div class=\"inner-sec-w3pvt py-lg-5 py-3\">\n      <h3 class=\"tittle text-center mb-lg-5 mb-3 px-lg-5\"><span class=\"sub-tittle\"></span>Get everything you need\n        to pick the right Agent.</h3>\n      <!---728x90--->\n      <div class=\"feature-grids row mt-3 mb-lg-5 mb-3 text-center\">\n        <div class=\"col-lg-4\" data-aos=\"fade-up\">\n          <div class=\"bottom-gd px-3\">\n            <span class=\"fa fa-building-o\" aria-hidden=\"true\"></span>\n            <h3 class=\"my-4\"> Integrity</h3>\n            <p>We say what we mean and do what we say. We act with unconditional honesty, respect, and courtesy at all\n              times.</p>\n          </div>\n        </div>\n        <div class=\"col-lg-4\" data-aos=\"fade-up\">\n          <div class=\"bottom-gd2-active px-3\">\n            <span class=\"fa fa-cogs\" aria-hidden=\"true\"></span>\n            <h3 class=\"my-4\"> Quality</h3>\n            <p>Quality is best measured with a view outward to the customer, inward to employees, and cross functionally\n              within the organization.</p>\n          </div>\n        </div>\n        <div class=\"col-lg-4\" data-aos=\"fade-up\">\n          <div class=\"bottom-gd px-3\">\n            <span class=\"fa fa-cogs\" aria-hidden=\"true\"></span>\n            <h3 class=\"my-4\">Innovation</h3>\n            <p>We encourage creativity and embrace new ideas in all aspects of our work without judgment or criticism;\n              innovation drives our future.</p>\n          </div>\n        </div>\n\n      </div>\n      <!-- services -->\n      <div class=\"fetured-info pt-lg-5\">\n        <h3 class=\"tittle  text-center my-lg-5 my-3\"><span class=\"sub-tittle\"></span> Mission & Vision\n        </h3>\n        <div class=\"row fetured-sec mt-lg-5 mt-3\">\n          <div class=\"col-lg-6 p-0\">\n            <div class=\"img-effect\">\n              <img src=\"assets/images/img1.jpg\" alt=\"\" class=\"img-fluid image1\">\n            </div>\n\n          </div>\n          <div class=\"col-lg-6 serv_bottom feature-grids pl-lg-5\">\n            <div class=\"featured-left text-left\">\n              <div class=\"bottom-gd px-3\">\n                <!-- <span class=\"fa fa-key\" aria-hidden=\"true\"></span> -->\n                <h3 class=\"my-4\">Our Mission</h3>\n                <p>“N1RE’s aim is to strive to be able to meet and exceed our customer's expectation. Our mission is to\n                  change the way people live, work and play with our landmark architectural design and to provide a\n                  complete and holistic approach to architecture.”</p>\n              </div>\n              <div class=\"bottom-gd fea active p-4\" data-aos=\"fade-left\">\n                <span class=\"fa fa-hospital-o\" aria-hidden=\"true\"></span>\n\n                <h3 class=\"my-3 \">Our Vision</h3>\n                <p>N1re aims to be one of the top ten real estate companies in India over the coming decade,\n                  providing services of unrivaled quality. We desire to reconnect modernism with the idea of eco living\n                  to nurture living spaces that are sustainable, livable, contextual, economical and beautiful.”</p>\n              </div>\n            </div>\n          </div>\n        </div>\n      </div>\n\n    </div>\n  </div>\n  <!-- //services -->\n</section>\n<section class=\"hand-crafted py-5\">\n  <div class=\"container py-lg-5\">\n    <div class=\"row accord-info\">\n      <div class=\"col-lg-6 pl-md-5\">\n        <h3 class=\"mb-md-5 tittle\">This is Our Responsibility To Give Good Property</h3>\n        <p>n1re's large volume of listings and market share assure that we will generate calls from prospects\n          looking for commercial real estate; therefore, your property has an excellent opportunity to be considered for\n          purchase or lease.</p>\n        <p class=\"mt-3\">commercial real estate listings now quicker and more convenient with us than ever before based\n          on the property type you are most looking\n        <p>\n      </div>\n      <div class=\"col-lg-6 banner-image\">\n        <div class=\"img-effect\">\n          <img src=\"assets/images/img3.jpg\" alt=\"\" class=\"img-fluid image1\">\n        </div>\n      </div>\n    </div>\n  </div>\n</section>\n\n<div class=\"testimonials py-md-5 py-5\">\n  <div class=\"container py-xl-5 py-lg-3\">\n    <h3 class=\"tittle  text-center mb-lg-5 mb-3\"><span class=\"sub-tittle\">Clients Reviews</span> What Our Clients Say\n    </h3>\n    <owl-carousel-o [options]=\"testimonialslide\">\n      <ng-container>\n        <ng-template carouselSlide>\n          <div class=\"testimonials_grid_w3ls mt-lg-0 mt-4\">\n            <div class=\"p-md-5 p-4\">\n              <p class=\"sub-test\"><span class=\"fa fa-quote-left\" aria-hidden=\"true\"></span> \"Was wonderful, made the\n                process so easy and stress free. His experience and knowledge of real estate are second to none. When he\n                says his job is to get the best deal for his client, he really means it. I will recommend Alex to\n                everybody.\"\n              </p>\n              <div class=\"row mt-4\">\n                <div class=\"col-9 testi_grid mt-xl-3 mt-lg-2 mt-md-4 mt-2\">\n                  <h5 class=\"mb-2\">Debbie K.</h5>\n                </div>\n              </div>\n            </div>\n          </div>\n        </ng-template>\n        <ng-template carouselSlide>\n          <div class=\"testimonials_grid_w3ls mt-lg-0 mt-4\">\n            <div class=\"p-md-5 p-4\">\n              <p class=\"sub-test\"><span class=\"fa fa-quote-left\" aria-hidden=\"true\"></span> \"When I was younger I didn't\n                know it then, but the house that I grew up in and still live in currently with my parents was saved from\n                foreclosure thanks to Alex and his keen expertise in the real estate market and pursuit. I forever thank\n                him for the first home my immediate family sought to purchase.\"\n              </p>\n              <div class=\"row mt-4\">\n                <div class=\"col-9 testi_grid mt-xl-3 mt-lg-2 mt-md-4 mt-2\">\n                  <h5 class=\"mb-2\">Juleon </h5>\n                </div>\n              </div>\n            </div>\n          </div>\n        </ng-template>\n        <ng-template carouselSlide>\n          <div class=\"testimonials_grid_w3ls mt-lg-0 mt-4\">\n            <div class=\"p-md-5 p-4\">\n              <p class=\"sub-test\"><span class=\"fa fa-quote-left\" aria-hidden=\"true\"></span> The team\n                helped us with the sale if our house and the purchase of our new home. The experience was excellent, and\n                we would recommend him and his team to anyone that's thinking of buying or selling real estate.\n              </p>\n              <div class=\"row mt-4\">\n                <div class=\"col-9 testi_grid mt-xl-3 mt-lg-2 mt-md-4 mt-2\">\n                  <h5 class=\"mb-2\">Mukesh</h5>\n                </div>\n              </div>\n            </div>\n          </div>\n        </ng-template>\n      </ng-container>\n    </owl-carousel-o>\n  </div>\n</div>\n\n<section class=\"w3l-features-4\" style=\"background-color: #fafafa;\">\n  <div id=\"features4-block\" class=\"section-gap\">\n    <div class=\"wrapper\">\n      <div class=\"section-title align-center text-center\">\n        <h4>Our Gallery</h4>\n      </div>\n      <owl-carousel-o [options]=\"gallery\">\n        <ng-container>\n          <ng-template carouselSlide>\n            <div class=\"cfeatured-content\">\n              <img src=\"assets/images/gallery/img.jpg\" alt=\"\" class=\"img-fluid image1\">\n              <div class=\"property-info-list\">\n                <div class=\"detail\">\n                  <h4 class=\"title\">\n                    <a>Industrial</a>\n                  </h4>\n                </div>\n              </div>\n            </div>\n          </ng-template>\n          <ng-template carouselSlide>\n            <div class=\"cfeatured-content\">\n              <img src=\"assets/images/gallery/img1.jpg\" alt=\"\" class=\"img-fluid image1\">\n              <div class=\"property-info-list\">\n                <div class=\"detail\">\n                  <h4 class=\"title\">\n                    <a>Office</a>\n                  </h4>\n                </div>\n              </div>\n            </div>\n          </ng-template>\n          <ng-template carouselSlide>\n            <div class=\"cfeatured-content\">\n              <img src=\"assets/images/gallery/img2.jpg\" alt=\"\" class=\"img-fluid image1\">\n              <div class=\"property-info-list\">\n                <div class=\"detail\">\n                  <h4 class=\"title\">\n                    <a>Multi-Family</a>\n                  </h4>\n                </div>\n              </div>\n            </div>\n          </ng-template>\n          <ng-template carouselSlide>\n            <div class=\"cfeatured-content\">\n              <img src=\"assets/images/gallery/img3.jpg\" alt=\"\" class=\"img-fluid image1\">\n              <div class=\"property-info-list\">\n                <div class=\"detail\">\n                  <h4 class=\"title\">\n                    <a>Specialty</a>\n                  </h4>\n                </div>\n              </div>\n            </div>\n          </ng-template>\n          <ng-template carouselSlide>\n            <div class=\"cfeatured-content\">\n              <img src=\"assets/images/gallery/img4.jpg\" alt=\"\" class=\"img-fluid image1\">\n              <div class=\"property-info-list\">\n                <div class=\"detail\">\n                  <h4 class=\"title\">\n                    <a>Retail</a>\n                  </h4>\n                </div>\n              </div>\n            </div>\n          </ng-template>\n          <ng-template carouselSlide>\n            <div class=\"cfeatured-content\">\n              <img src=\"assets/images/gallery/img7.jpg\" alt=\"\" class=\"img-fluid image1\">\n              <div class=\"property-info-list\">\n                <div class=\"detail\">\n                  <h4 class=\"title\">\n                    <a>Land</a>\n                  </h4>\n                </div>\n              </div>\n            </div>\n          </ng-template>\n        </ng-container>\n      </owl-carousel-o>\n    </div>\n  </div>\n</section>"

/***/ }),

/***/ "./src/app/modules/home/pages/home/home.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/modules/home/pages/home/home.component.ts ***!
  \***********************************************************/
/*! exports provided: HomeComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomeComponent", function() { return HomeComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var HomeComponent = /** @class */ (function () {
    function HomeComponent(router) {
        this.router = router;
        //gallery
        this.gallery = {
            // items: 1,
            loop: true,
            mouseDrag: true,
            touchDrag: true,
            pullDrag: false,
            dots: false,
            // autoWidth: true,
            // autoHeight: true,
            navSpeed: 700,
            navText: [
                '<i class="fa fa-angle-left"></i>',
                '<i class="fa fa-angle-right"></i>',
            ],
            responsive: {
                0: {
                    items: 1,
                },
                400: {
                    items: 2,
                },
                740: {
                    items: 3,
                },
                940: {
                    items: 4,
                },
                1024: {
                    items: 5,
                },
            },
            nav: true,
        };
        //testimonial
        this.testimonialslide = {
            // items: 1,
            loop: true,
            mouseDrag: true,
            touchDrag: true,
            pullDrag: false,
            dots: false,
            // autoWidth: true,
            // autoHeight: true,
            navSpeed: 700,
            navText: [
                '<i class="fa fa-angle-left"></i>',
                '<i class="fa fa-angle-right"></i>',
            ],
            responsive: {
                0: {
                    items: 1,
                },
                400: {
                    items: 2,
                },
                740: {
                    items: 3,
                },
                940: {
                    items: 2,
                },
                1024: {
                    items: 2,
                },
            },
            nav: true,
        };
        //testimonial
        this.bannerslide = {
            // items: 1,
            loop: true,
            mouseDrag: true,
            touchDrag: true,
            pullDrag: false,
            dots: false,
            nav: false,
            // autoWidth: true,
            // autoHeight: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplayHoverPause: true,
            navText: [
                '<i class="fa fa-angle-left"></i>',
                '<i class="fa fa-angle-right"></i>',
            ],
            responsive: {
                0: {
                    items: 1,
                },
                400: {
                    items: 1,
                },
                740: {
                    items: 1,
                },
                940: {
                    items: 1,
                },
                1024: {
                    items: 1,
                },
            },
        };
    }
    HomeComponent.prototype.ngOnInit = function () { };
    HomeComponent.prototype.navigate = function () {
        this.router.navigateByUrl("about/package");
    };
    HomeComponent.prototype.readMore = function () {
        this.router.navigateByUrl("about");
    };
    HomeComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: "app-home",
            template: __webpack_require__(/*! ./home.component.html */ "./src/app/modules/home/pages/home/home.component.html"),
            styles: [__webpack_require__(/*! ./home.component.css */ "./src/app/modules/home/pages/home/home.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])
    ], HomeComponent);
    return HomeComponent;
}());



/***/ })

}]);
//# sourceMappingURL=src-app-modules-home-home-module.js.map